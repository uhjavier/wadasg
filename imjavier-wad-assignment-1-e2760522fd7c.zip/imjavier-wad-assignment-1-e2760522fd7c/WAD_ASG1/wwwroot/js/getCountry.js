﻿const carList = [
    ["Singapore", "Singapore"],
    ["Malaysia", "Kuala Lumpur"],
    ["China", "Hong Kong"],
    ["China", "Beijing"],
    ["USA", "New York"],
    ["USA", "San Francisco"],
    ["France", "Paris"],
    ["Australia", "Sydney"],
    ["UK", "London"],
]

// generic function to get a unique array of values from an array given an index
function getUniqueList(data, index) {
    const uniqueList = new Set();

    data.forEach(item => {
        uniqueList.add(item[index]);
    })
    return [...uniqueList];
}

// function to populate an existing HTML select element given a unique array of values
function makeDropDown(data, element) {
    const selectElement = document.getElementById(element);

    selectElement.innerHTML = "";

    data.forEach(item => {
        const option = document.createElement('option');
        option.innerText = item;
        selectElement.appendChild(option);
    })
}

// function that runs once when the DOM is loaded
function contentLoaded() {
    const uniqueList = getUniqueList(carList, 0);
    makeDropDown(uniqueList, 'toCountry');
    populateVehicleModels();
}

// function that gets called when the first dropdown is changed.
// It will populate the second, cascading dropdown.
function populateVehicleModels() {
    const vehicleMake = document.getElementById('toCountry').value;

    const filteredArray = carList.filter(item => {
        return item[0] === vehicleMake;
    })

    const uniqueList = getUniqueList(filteredArray, 1);

    makeDropDown(uniqueList, 'toCity');
}

document.addEventListener('DOMContentLoaded', contentLoaded);
document.getElementById('toCountry').addEventListener('change', populateVehicleModels);