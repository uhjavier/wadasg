﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace WAD_ASG1.Models
{
    public class ParcelWithDelvHist
    {
        [Required(ErrorMessage = "Please enter the Parcel ID")]
        [Display(Name = "Parcel ID")]
        public int ParcelID { get; set; }

        [StringLength(255, ErrorMessage = "The Item Desscription is too long")]
        [Display(Name = "Item Description")]
        public string? ItemDescription { get; set; }

        [Required(ErrorMessage = "Please enter the Sender Name")]
        [StringLength(50, ErrorMessage = "The Sender Name is too long")]
        [Display(Name = "Sender Name")]
        public string SenderName { get; set; }

        [Required(ErrorMessage = "Please enter the sender contact number")]
        [StringLength(20, ErrorMessage = "The send contact number is too long")]
        [Display(Name = "Sender Contact Number")]
        public string SenderTelNo { get; set; }

        [Required(ErrorMessage = "Please enter the receiver name")]
        [StringLength(50, ErrorMessage = "The receiver name is too long")]
        [Display(Name = "Receiver Name")]
        public string ReceiverName { get; set; }

        [Required(ErrorMessage = "Please enter the receiver contact number")]
        [StringLength(20, ErrorMessage = "The receiver contact number is too long")]
        [Display(Name = "Receiver Contact Number")]
        public string ReceiverTelNo { get; set; }

        [Required(ErrorMessage = "Please enter the delivery address")]
        [StringLength(255, ErrorMessage = "The delivery is too long")]
        [Display(Name = "Delivery Address")]
        public string DeliveryAddress { get; set; }

        [Required(ErrorMessage = "Please enter delivery departure city name")]
        [StringLength(50, ErrorMessage = "The delivery departure city name is too long")]
        [Display(Name = "Depature City")]
        public string FromCity { get; set; }

        [Required(ErrorMessage = "Please enter delivery departure country name")]
        [StringLength(50, ErrorMessage = "The delivery departure country name is too long")]
        [Display(Name = "Depature country")]
        public string FromCountry { get; set; }

        [Required(ErrorMessage = "Please enter delivery arrival city name")]
        [StringLength(50, ErrorMessage = "The delivery arrival city name is too long")]
        [Display(Name = "Arrival City")]
        public string ToCity { get; set; }

        [Required(ErrorMessage = "Please enter delivery arrival country name")]
        [StringLength(50, ErrorMessage = "The delivery arrival country name is too long")]
        [Display(Name = "Arrival country")]
        public string ToCountry { get; set; }

        [Required(ErrorMessage = "Please enter the parcel weight")]
        [DisplayFormat(DataFormatString = "{0:#,##0.0}")]
        [Display(Name = "Parcel Weight")]
        public double ParcelWeight { get; set; }

        [Required(ErrorMessage = "Please enter the delivery charge")]
        [DataType(DataType.Currency)]
        [Display(Name = "Delivery Charge")]
        public decimal DeliveryCharge { get; set; }

        [Required(ErrorMessage = "Please enter the currency code")]
        [StringLength(3, MinimumLength = 3, ErrorMessage = "The currency code is not 3 letters")]
        [Display(Name = "Currency")]
        public string Currency { get; set; }

        [Required(ErrorMessage = "Please enter the target delivery arrival date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}")]
        [Display(Name = "Target Delivery Date")]
        public DateTime? TargetDeliveryDate { get; set; }

        [Required(ErrorMessage = "Please enter the delivery status")]
        [Range(0, 4, ErrorMessage = "Please update the delivery status again")]
        [Display(Name = "Delivery Status")]
        public string DeliveryStatus { get; set; }

        [Required(ErrorMessage = "Please enter the Delivery Man ID")]
        [Display(Name = "Delivery Man ID")]
        public int? DeliveryManID { get; set; }

        [Required(ErrorMessage = "Please enter the record ID")]
        [Display(Name = "Record ID")]
        public int RecordID { get; set; }


        [Required(ErrorMessage = "Please enter the delivery process description")]
        [StringLength(255, ErrorMessage = "The delivery process description is too long")]
        [Display(Name = "Delivery Process Description")]
        public string Description { get; set; }

    }
}
