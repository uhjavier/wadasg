﻿using System.ComponentModel.DataAnnotations;


namespace WAD_ASG1.Models
{
    public class DeliveryFailure
    {
        [Required(ErrorMessage ="Please enter the report ID")]
        [Display(Name ="Report ID")]
        public int ReportID { get; set; }

        [Required(ErrorMessage = "Please enter the parcel ID")]
        [Display(Name = "Parcel ID")]
        public int ParcelID { get; set; }

        [Required(ErrorMessage = "Please enter the Delivery Man ID")]
        [Display(Name = "Delivery Man ID")]
        public int DeliveryManID { get; set; }

        [Required(ErrorMessage = "Please enter the delivery failure type")]
        [Range(1,4,ErrorMessage ="Please select the delivery failure type again")]
        [Display(Name = "Failure Type")]
        public string FailureType { get; set; }


        [Required(ErrorMessage = "Please enter the delivery history description")]
        [StringLength(255, ErrorMessage = "The delivery history description is too long")]
        [Display(Name = "Description")]
        public string Description { get; set; }


      
        [StringLength(255, ErrorMessage = "The delivery process description is too long")]
        [Display(Name = "Station Manager ID")]
        public int? StationMgrID { get; set; }

        
        [StringLength(255, ErrorMessage = "The follow up action is too long")]
        [Display(Name = "Follow Up Action")]
        public string? FollowUpAction { get; set; }

        [Required(ErrorMessage = "Please enter the delivery failure report date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}")]
        [Display(Name = "Delivery Failure Report Date")]
        public DateTime DateCreated { get; set; }
    }
    
}
