﻿namespace WAD_ASG1.Models
{
    public class combinedForecast
    {
        public WeatherForecast weatherForecast24hr { get; set; }

        public WeatherForecast2hr weatherForecast2hr{ get; set; }
    }
}
