﻿using System;
using System.Collections.Generic;

namespace WAD_ASG1.Models
{
    public class WeatherForecast2hr
    {
        public List<AreaMetadata> Area_Metadata { get; set; }
        public List<WeatherItems2hr> Items { get; set; }
        public ApiInfo Api_Info { get; set; }
    }

    public class AreaMetadata
    {
        public string Name { get; set; }
        public LabelLocation Label_Location { get; set; }
    }

    public class LabelLocation
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }

    public class WeatherItems2hr
    {
        public DateTimeOffset Update_Timestamp { get; set; }
        public DateTimeOffset Timestamp { get; set; }
        public ForecastPeriod Valid_Period { get; set; }
        public List<Forecasts> Forecasts { get; set; }
    }

    public class ForecastPeriod
    {
        public DateTimeOffset Start { get; set; }
        public DateTimeOffset End { get; set; }
    }

    public class Forecasts
    {
        public string Area { get; set; }
        public string Forecast { get; set; }
    }

}
