﻿using System.ComponentModel.DataAnnotations;
using WAD_ASG1.DAL;

namespace WAD_ASG1.Models
{
    public class ValidateMemberEmailExists: ValidationAttribute
    {
        private memberDAL memberContext = new memberDAL();
        protected override ValidationResult IsValid(
        object value, ValidationContext validationContext)
        {
            // Get the email value to validate
            string email = Convert.ToString(value);
            // Casting the validation context to the "Staff" model class
            Member member = (Member)validationContext.ObjectInstance;
            // Get the Staff Id from the staff instance
            if (memberContext.IsEmailExist(email))
                // validation failed
                return new ValidationResult
                ("Email address already exists!");
            else
                // validation passed 
                return ValidationResult.Success;
        }
        
    }
}
