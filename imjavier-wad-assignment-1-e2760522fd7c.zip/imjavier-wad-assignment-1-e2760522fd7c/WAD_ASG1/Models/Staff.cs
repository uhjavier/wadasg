﻿using System.ComponentModel.DataAnnotations;

namespace WAD_ASG1.Models
{
    public class Staff
    {
        [Required(ErrorMessage = "Please enter your Staff ID")]
        [Display(Name = "Staff ID")]
        public int StaffID { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Staff Name")]
        [StringLength(50, ErrorMessage = "Your name is too long")]
        public string StaffName { get; set; }

        [Required(ErrorMessage = "Please enter a valid loginID")]
        [Display (Name = "Staff Login ID")]
        public string StaffLoginID { get; set; }

        [Required(ErrorMessage = "Please enter a valid password")]
        [StringLength(25,ErrorMessage ="Your password is too long")]
        [Display(Name = "Staff Password")]
        public string Password{ get; set; }

        [Required(ErrorMessage = "Please enter an appointment role")]
        [StringLength(50,ErrorMessage = "The appointment role is too long")]
        [Display(Name = "Appointed Role")]
        public string Appointment { get; set; }

        [Required(ErrorMessage = "Please enter your office contact number")]
        [StringLength(20, ErrorMessage = "The office contact number is too long")]
        [Display(Name = "Office Tel No")]
        public string OfficeTelNo { get; set; }

        [Required(ErrorMessage ="Please enter your office location")]
        [StringLength(50,ErrorMessage = "The location name is too long ")]
        [Display(Name = "Location")]
        public string Location { get; set; }
    }
}
