﻿using System.ComponentModel.DataAnnotations;



namespace WAD_ASG1.Models
{
    public class ShippingRates
    {
        [Required(ErrorMessage="Please enter your ShippingRate ID")]
        [Display(Name = "Shipping Rate ID")]
        public int ShippingRateID { get; set; }

        [Required(ErrorMessage = "Please enter delivery departure city name")]
        [StringLength(50,ErrorMessage = "The delivery departure city name is too long")]
        [Display(Name = "Depature City")]
        public string FromCity { get; set; }

        [Required(ErrorMessage = "Please enter delivery departure country name")]
        [StringLength(50, ErrorMessage = "The delivery departure country name is too long")]
        [Display(Name = "Depature Country")]
        public string FromCountry { get; set; }

        [Required(ErrorMessage = "Please enter delivery arrival city name")]
        [StringLength(50, ErrorMessage = "The delivery arrival city name is too long")]
        [Display(Name = "Arrival City")]
        public string ToCity { get; set; }

        [Required(ErrorMessage = "Please enter delivery arrival country name")]
        [StringLength(50, ErrorMessage = "The delivery arrival country name is too long")]
        [Display(Name = "Arrival Country")]
        public string ToCountry { get; set; }

        [Required(ErrorMessage = "Please enter shipping rate")]
        [DataType(DataType.Currency)]
        public decimal ShippingRate { get; set; }

        [Required(ErrorMessage = "Please enter the currency code")]
        [StringLength(3, MinimumLength = 3 ,ErrorMessage = "The currency code is not 3 letters")]
        [Display(Name = "Currency")]
        public string Currency { get; set; }


        [Required(ErrorMessage = "Please enter the number of day(s) for transit")]
        [Display(Name = "Transit Time")]
        public int TransitTime { get; set; }

        [Required(ErrorMessage = "Please enter the staff ID")]
        [Display(Name = "Last Update By ")]
        public int LastUpdatedBy { get; set; }
    }
}
