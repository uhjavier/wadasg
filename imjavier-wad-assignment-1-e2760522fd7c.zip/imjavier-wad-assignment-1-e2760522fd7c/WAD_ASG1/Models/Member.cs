﻿using System.ComponentModel.DataAnnotations;
using WAD_ASG1.DAL;


namespace WAD_ASG1.Models
{
    public class Member
    {
        [Required(ErrorMessage = "Please enter the Member ID")]
        [Display(Name = "Member ID")]
        public int MemberId { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Name")]
        [StringLength(50, ErrorMessage = "Your name is too long")]
        public string MemberName { get; set; }

        [Required(ErrorMessage = "Please enter your salutation")]
        [StringLength(5, ErrorMessage = "The salutation is too long")]
        [Display(Name = "Salutation")]
        public string Salutation { get; set; }

        [Required(ErrorMessage = "Please enter your contact number")]
        [StringLength(20, ErrorMessage = "The contact number is too long")]
        [Display(Name = "Contact Number")]
        public string TelNo { get; set; }

        [Display(Name = "Email Address")]
        [Required(ErrorMessage = "Please enter your email address")]
        [EmailAddress]
        [ValidateMemberEmailExists]
        [RegularExpression(@"[A-Za-z0-9..% +-I +@ A - Za - zo - 9.-]+\. [A-Za-z]{2,4}", ErrorMessage = "Invalid email address format!")]
        public string EmailAddr { get; set; }

        [Required(ErrorMessage = "Please enter a valid password")]
        [StringLength(25, ErrorMessage = "Your password is too long")]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Date Of Birth")]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}")]
        public DateTime? BirthDate { get; set; }

        [StringLength(50, ErrorMessage = "The city name is too long")]
        [Display(Name = "City")]
        public string? City { get; set; }

        [Required(ErrorMessage = "Please enter your country")]
        [StringLength(50, ErrorMessage = "The city name is too long")]
        [Display(Name = "Country")]
        public string Country { get; set; }



    }
}
