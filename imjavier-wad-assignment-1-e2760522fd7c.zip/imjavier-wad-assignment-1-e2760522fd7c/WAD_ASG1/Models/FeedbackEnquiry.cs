﻿using System.ComponentModel.DataAnnotations;

namespace WAD_ASG1.Models
{
    public class FeedbackEnquiry
    {
        [Required(ErrorMessage ="Please enter the Feedback Enquiry ID")]
        [Display(Name ="Feedback Enquiry ID")]
        public int FeedbackEnquiryID { get; set; }

        [Required(ErrorMessage = "Please enter the Member ID")]
        [Display(Name = "Member ID")]
        public int MemberID { get; set; }

        [Required(ErrorMessage = "Please enter the feedback enquiry content")]
        [StringLength(255,ErrorMessage ="The feedback enquiry content is too long")]
        [Display(Name = "Content")]
        public string Content { get; set; }

        [Required(ErrorMessage = "Please enter the date of the feedback enquiry is posted")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}")]
        [Display(Name = " Feedback Enquiry Date Posted")]
        public DateTime DateTimePosted { get; set; }

        [Required(ErrorMessage = "Please enter the Staff ID")]
        [Display(Name = "Staff ID")]
        public int? StaffID { get; set; }

        [StringLength(255, ErrorMessage = "The feedback enquiry response is too long")]
        [Display(Name = " Feedback Enquiry's Response")]
        public string? Response { get; set; }

        [Required(ErrorMessage = "Please enter the delivery feedback enquiry status")]
        [Range(0, 1, ErrorMessage = "Please select the delivery feedback enquiry status again")]
        [Display(Name = "Feedback Enquiry Status")]
        public string Status { get; set; }
    }
}
