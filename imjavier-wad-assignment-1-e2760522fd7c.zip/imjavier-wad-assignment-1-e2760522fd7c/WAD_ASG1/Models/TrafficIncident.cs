﻿using System.Text.Json.Serialization;

namespace WAD_ASG1.Models
{
    public class Incident
    {
        public string Type { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Message { get; set; }
    }

    public class TrafficIncident
    {
        [JsonPropertyName("odata.metadata")]
        public string Metadata { get; set; }

        public List<Incident> Value { get; set; }
    }

}

