﻿using System.ComponentModel.DataAnnotations;


namespace WAD_ASG1.Models
{
    public class CashVoucher
    {
        [Required(ErrorMessage = "Please enter the Cash Voucher ID")]
        [Display(Name = "Cash Voucher ID")]
        public int CashVoucherID { get; set; }

        [Required(ErrorMessage = "Please enter the Staff ID")]
        [Display(Name = "Staff ID")]
        public int StaffID { get; set; }

        [Required(ErrorMessage = "Please enter the cash voucher amount")]
        [DataType(DataType.Currency)]
        [Display(Name = "Cash Voucher Amount")]
        public double Amount { get; set; }

        [Required(ErrorMessage = "Please enter the currency code")]
        [StringLength(3, MinimumLength = 3, ErrorMessage = "The currency code is not 3 letters")]
        [Display(Name = "Currency")]
        public string Currency { get; set; }

        [Required(ErrorMessage = "Please enter the cash voucher issuing code")]
        [Range(1,3, ErrorMessage = "Please enter the cash voucher issuing code again")]
        [Display(Name = "Issuing Code")]
        public string IssuingCode { get; set; }

        [Required(ErrorMessage = "Please enter the receiver name")]
        [StringLength(50, ErrorMessage = "The receiver name is too long")]
        [Display(Name = "Receiver Name")]
        public string ReceiverName { get; set; }

        [Required(ErrorMessage = "Please enter the receiver contact number")]
        [StringLength(20, ErrorMessage = "The receiver contact number is too long")]
        [Display(Name = "Receiver Contact Number")]
        public string ReceiverTelNo { get; set; }

        [Required(ErrorMessage ="Please enter the datetime of cash voucher issued ")]
        [DataType(DataType.Date)]
        [Display(Name = "Date Time Issued")]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}")]
        public DateTime DateTimeIssued { get; set; }

        [Required(ErrorMessage = "Please enter the cash voucher collection status")]
        [Range(0, 1, ErrorMessage = "Please select the cash voucher collection status again")]
        [Display(Name = "Cash Voucher Collection Status")]
        public string Status { get; set; }
    }
}
