﻿using System.ComponentModel.DataAnnotations;

namespace WAD_ASG1.Models
{
    public class DeliveryHistory
    {
        [Required(ErrorMessage="Please enter the record ID")]
        [Display(Name ="Record ID")]
        public int RecordID { get; set; }

        [Required(ErrorMessage = "Please enter the parcel ID")]
        [Display(Name = "Parcel ID")]
        public int ParcelID { get; set; }

        [Required(ErrorMessage = "Please enter the delivery process description")]
        [StringLength(255,ErrorMessage ="The delivery process description is too long")]
        [Display(Name ="Delivery Process Description")]
        public string Description { get; set; }
    }
}
