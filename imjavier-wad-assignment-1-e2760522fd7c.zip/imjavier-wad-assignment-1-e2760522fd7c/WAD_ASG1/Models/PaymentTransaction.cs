﻿using System.ComponentModel.DataAnnotations;

namespace WAD_ASG1.Models
{
    public class PaymentTransaction
    {
        [Required(ErrorMessage ="Please enter the transaction ID")]
        [Display(Name ="Transaction ID")]
        public int TransactionID { get; set; }

        [Required(ErrorMessage = "Please enter the parcel ID")]
        [Display(Name = "Parcel ID")]
        public int ParcelID { get; set; }

        [Required(ErrorMessage = "Please enter the amount of the payment transaction")]
        [DataType(DataType.Currency)]
        [Display(Name = "Payment Transaction Amount")]
        public double AmtTran { get; set; }

        [Required(ErrorMessage = "Please enter the currency code")]
        [StringLength(3, MinimumLength = 3, ErrorMessage = "The currency code is not 3 letters")]
        [Display(Name = "Currency")]
        public string Currency { get; set; }

        [Required(ErrorMessage = "Please enter the transaction type code")]
        [StringLength(4, MinimumLength = 4, ErrorMessage = "The transaction type code is not 4 letters")]
        [Display(Name = "Transaction Type")]
        public string TranType { get; set; }


        [Required(ErrorMessage = "Please enter the target transaction date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}")]
        [Display(Name = "Transactio Date")]
        public DateTime TranDate { get; set; }
    }
}
