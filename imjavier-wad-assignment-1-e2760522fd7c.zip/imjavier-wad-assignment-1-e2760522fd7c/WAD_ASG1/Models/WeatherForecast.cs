﻿using System;
using System.Collections.Generic;

namespace WAD_ASG1.Models
{
    public class WeatherForecast
    {
        public List<WeatherItem> Items { get; set; }
        

        public ApiInfo Api_Info { get; set; }
    }

    public class WeatherItem
    {
        public DateTimeOffset Update_Timestamp { get; set; }

        public DateTimeOffset Timestamp { get; set; }
        public ValidPeriod Valid_Period { get; set; }
        public GeneralInfo General { get; set; }
        public List<WeatherPeriod> Periods { get; set; }
    }

    public class ValidPeriod
    {
        public DateTimeOffset Start { get; set; }
        public DateTimeOffset End { get; set; }
    }

    public class GeneralInfo
    {
        public string Forecast { get; set; }
        public RelativeHumidity Relative_Humidity { get; set; }
        public TemperatureInfo Temperature { get; set; }
        public WindInfo Wind { get; set; }
    }

    public class RelativeHumidity
    {
        public int Low { get; set; }
        public int High { get; set; }
    }

    public class TemperatureInfo
    {
        public int Low { get; set; }
        public int High { get; set; }
    }

    public class WindInfo
    {
        public WindSpeed Speed { get; set; }
        public string Direction { get; set; }
    }

    public class WindSpeed
    {
        public int Low { get; set; }
        public int High { get; set; }
    }

    public class WeatherPeriod
    {
        public WeatherTime Time { get; set; }
        public Dictionary<string, string> Regions { get; set; }
    }

    public class WeatherTime
    {
        public DateTimeOffset Start { get; set; }
        public DateTimeOffset End { get; set; }
    }

    public class ApiInfo
    {
        public string Status { get; set; }
    }
}
