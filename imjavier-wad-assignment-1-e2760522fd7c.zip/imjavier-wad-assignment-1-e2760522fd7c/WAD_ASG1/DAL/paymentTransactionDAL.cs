﻿using System.Data.SqlClient;
using WAD_ASG1.Models;

namespace WAD_ASG1.DAL
{
    public class paymentTransactionDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public paymentTransactionDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<PaymentTransaction> GetAllPaymentTransaction()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM  PaymentTransaction ORDER BY TransactionID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<PaymentTransaction> PaymentTransactionList = new List<PaymentTransaction>();
            while (reader.Read())
            {
                PaymentTransactionList.Add(
                new PaymentTransaction
                {
                    TransactionID = reader.GetInt32(0),
                    ParcelID = reader.GetInt32(1),
                    AmtTran = reader.GetDouble(2),
                    Currency = reader.GetString(3),
                    TranType = reader.GetString(4),
                    TranDate = reader.GetDateTime(5)
                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return PaymentTransactionList;
        }

        public bool Add(PaymentTransaction paymentTransaction)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO PaymentTransaction (ParcelID, AmtTran, Currency, TranType, TranDate) 
                                OUTPUT INSERTED.TransactionID 
                                VALUES(@parcelid, @amttra, @currency, @trantype, @trandate)";

            cmd.Parameters.AddWithValue("@parcelid", paymentTransaction.ParcelID);
            cmd.Parameters.AddWithValue("@amttra", paymentTransaction.AmtTran);
            cmd.Parameters.AddWithValue("@currency", paymentTransaction.Currency);
            cmd.Parameters.AddWithValue("@trantype", paymentTransaction.TranType);
            cmd.Parameters.AddWithValue("@trandate", paymentTransaction.TranDate);
            conn.Open();
            paymentTransaction.TransactionID = (int)cmd.ExecuteScalar();
            conn.Close();
            return true;
        }

        
    }
}
