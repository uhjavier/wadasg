﻿using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using WAD_ASG1.Models;


namespace WAD_ASG1.DAL
{
    
    public class shippingRateDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor

        public shippingRateDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }

        public List<ShippingRates> GetAllShippingRate()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM ShippingRate ORDER BY ShippingRateID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<ShippingRates> ShippingRate = new List<ShippingRates>();
            while (reader.Read())
            {
                ShippingRate.Add(
                new ShippingRates
                {
                    ShippingRateID = reader.GetInt32(0),
                    FromCity = reader.GetString(1),
                    FromCountry = reader.GetString(2),
                    ToCity = reader.GetString(3),
                    ToCountry = reader.GetString(4),
                    ShippingRate = reader.GetDecimal(5),
                    Currency = reader.GetString(6),
                    TransitTime = reader.GetInt32(7),
                    LastUpdatedBy = reader.GetInt32(8)


                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return ShippingRate;
        }

        public ShippingRates GetShippingRate(string toCity)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM ShippingRate WHERE ToCity = @ToCity";
            cmd.Parameters.AddWithValue("@ToCity", toCity);
            conn.Open();
            ShippingRates shippingSelected = new ShippingRates();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                shippingSelected.ShippingRateID = reader.GetInt32(0);
                shippingSelected.FromCity = reader.GetString(1);
                shippingSelected.FromCountry = reader.GetString(2);
                shippingSelected.ToCity = reader.GetString(3);
                shippingSelected.ToCountry = reader.GetString(4);
                shippingSelected.ShippingRate = reader.GetDecimal(5);
                shippingSelected.Currency = reader.GetString(6);
                shippingSelected.TransitTime = reader.GetInt32(7);
                shippingSelected.LastUpdatedBy = reader.GetInt32(8);

            }
            reader.Close();
            conn.Close();
            return shippingSelected;
        }


    }
}
