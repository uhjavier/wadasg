﻿using System.Data.SqlClient;
using WAD_ASG1.Models;

namespace WAD_ASG1.DAL
{
    public class cashVoucherDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public cashVoucherDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<CashVoucher> GetAllDeliveryFailure()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM CashVoucher ORDER BY CashVoucherID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<CashVoucher> CashVoucherList = new List<CashVoucher>();
            while (reader.Read())
            {
                CashVoucherList.Add(
                new CashVoucher
                {
                    CashVoucherID = reader.GetInt32(0),
                    StaffID = reader.GetInt32(1),
                    Amount = reader.GetDouble(2),
                    Currency = reader.GetString(3),
                    IssuingCode = reader.GetString(4),
                    ReceiverName = reader.GetString(5),
                    ReceiverTelNo = reader.GetString(6),
                    DateTimeIssued = reader.GetDateTime(7),
                    Status = reader.GetString(8)
                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return CashVoucherList;
        }
    }
}
