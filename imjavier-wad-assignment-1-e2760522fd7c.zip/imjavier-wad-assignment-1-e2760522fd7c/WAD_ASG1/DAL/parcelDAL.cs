﻿using Microsoft.AspNetCore.Connections.Features;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using WAD_ASG1.Models;

namespace WAD_ASG1.DAL
{
    public class parcelDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public parcelDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<Parcel> GetAllParcel()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM Parcel ORDER BY ParcelID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<Parcel> ParcelList = new List<Parcel>();
            while (reader.Read())
            {
                ParcelList.Add(
                new Parcel
                {
                    ParcelID = reader.GetInt32(0),
                    ItemDescription = reader.GetString(1),
                    SenderName = reader.GetString(2),
                    SenderTelNo = reader.GetString(3),
                    ReceiverName = reader.GetString(4),
                    ReceiverTelNo = reader.GetString(5),
                    DeliveryAddress = reader.GetString(6),
                    FromCity = reader.GetString(7),
                    FromCountry = reader.GetString(8),
                    ToCity = reader.GetString(9),
                    ToCountry = reader.GetString(10),
                    ParcelWeight = reader.GetFloat(11),
                    DeliveryCharge = reader.GetDecimal(12),
                    Currency = reader.GetString(13),
                    TargetDeliveryDate = reader.GetDateTime(14),
                    DeliveryStatus = reader.GetString(15),
                    DeliveryManID = reader.GetInt32(16)

                });
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return ParcelList;
        }

        public List<Parcel> getMemberParcels(Member User) 
        {
            List<Parcel> ParcelList = new();
            string Membername = User.MemberName;
            string MemberTelNo = User.TelNo;
            SqlCommand cmd = conn.CreateCommand();
            conn.Open();
            cmd.CommandText = @"SELECT * FROM Parcel WHERE (SenderName = @MemberName and SenderTelNo = @MemberTelNo) or (ReceiverName = @MemberName and ReceiverTelNo = @MemberTelNo)";
            cmd.Parameters.AddWithValue("MemberName", Membername);
            cmd.Parameters.AddWithValue("MemberTelNo", MemberTelNo);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ParcelList.Add(
                new Parcel
                {
                    ParcelID = reader.GetInt32(0),
                    ItemDescription = reader.GetString(1),
                    SenderName = reader.GetString(2),
                    SenderTelNo = reader.GetString(3),
                    ReceiverName = reader.GetString(4),
                    ReceiverTelNo = reader.GetString(5),
                    DeliveryAddress = reader.GetString(6),
                    FromCity = reader.GetString(7),
                    FromCountry = reader.GetString(8),
                    ToCity = reader.GetString(9),
                    ToCountry = reader.GetString(10),
                    ParcelWeight = reader.GetDouble(11),
                    DeliveryCharge = reader.GetDecimal(12),
                    Currency = reader.GetString(13),
                    TargetDeliveryDate = reader.GetDateTime(14),
                    DeliveryStatus = reader.GetString(15),
                    
                    DeliveryManID = !reader.IsDBNull(16) ?
                                       reader.GetInt32(16) : (int?)null

                });
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return ParcelList;
        }
        public List<Parcel> GetStaffParcelList(int deliverymanID)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM Parcel WHERE deliverymanid = @deliverymanID";
            cmd.Parameters.AddWithValue("@deliverymanID", deliverymanID);
            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();

            List<Parcel> ParcelList = new List<Parcel>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ParcelList.Add(
                    new Parcel
                    {
                        ParcelID = reader.GetInt32(0),
                        ItemDescription = reader.GetString(1),
                        SenderName = reader.GetString(2),
                        SenderTelNo = reader.GetString(3),
                        ReceiverName = reader.GetString(4),
                        ReceiverTelNo = reader.GetString(5),
                        DeliveryAddress = reader.GetString(6),
                        FromCity = reader.GetString(7),
                        FromCountry = reader.GetString(8),
                        ToCity = reader.GetString(9),
                        ToCountry = reader.GetString(10),
                        ParcelWeight = reader.GetDouble(11),
                        DeliveryCharge = reader.GetDecimal(12),
                        Currency = reader.GetString(13),
                        TargetDeliveryDate = reader.GetDateTime(14),
                        DeliveryStatus = reader.GetString(15),

                        DeliveryManID = !reader.IsDBNull(16) ?
                                       reader.GetInt32(16) : (int?)null


                    });
                }
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return ParcelList;
        }

        public int GetLastParcelID()
        {
            int maxParcelID = 0;

            // Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            // Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT MAX(ParcelID) FROM Parcel";
            // Open a database connection
            conn.Open();
            // Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                // Retrieve the maximum ParcelID value
                maxParcelID = reader.GetInt32(0);
            }

            // Close DataReader
            reader.Close();
            // Close the database connection
            conn.Close();

            return maxParcelID + 1;
        }

        public Parcel Add(Parcel parcel)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO Parcel (ItemDescription, SenderName, SenderTelNo, ReceiverName, ReceiverTelNo, DeliveryAddress, FromCity, FromCountry, ToCity, ToCountry, ParcelWeight, DeliveryCharge, Currency, TargetDeliveryDate, DeliveryStatus, DeliveryManID) 
                                OUTPUT INSERTED.ParcelID 
                                VALUES(@itemdescription, @sendername, @sendertelno, @receivername, @receivertelno, @deliveryaddress, @fromcity, @fromcountry, @tocity, @tocountry, @parcelweight, @deliverycharge, @currency, @targetdeliverydate, @deliverystatus, @deliverymanid)";

            cmd.Parameters.AddWithValue("@itemdescription", parcel.ItemDescription);
            cmd.Parameters.AddWithValue("@sendername", parcel.SenderName);
            cmd.Parameters.AddWithValue("@sendertelno", parcel.SenderTelNo);
            cmd.Parameters.AddWithValue("@receivername", parcel.ReceiverName);
            cmd.Parameters.AddWithValue("@receivertelno", parcel.ReceiverTelNo);
            cmd.Parameters.AddWithValue("@deliveryaddress", parcel.DeliveryAddress);
            cmd.Parameters.AddWithValue("@fromcity", parcel.FromCity);
            cmd.Parameters.AddWithValue("@fromcountry", parcel.FromCountry);
            cmd.Parameters.AddWithValue("@tocity", parcel.ToCity);
            cmd.Parameters.AddWithValue("@tocountry", parcel.ToCountry);
            cmd.Parameters.AddWithValue("@parcelweight", parcel.ParcelWeight);
            cmd.Parameters.AddWithValue("@deliverycharge", parcel.DeliveryCharge);
            cmd.Parameters.AddWithValue("@currency", parcel.Currency);
            cmd.Parameters.AddWithValue("@targetdeliverydate", parcel.TargetDeliveryDate);
            cmd.Parameters.AddWithValue("@deliverystatus", parcel.DeliveryStatus);
            cmd.Parameters.AddWithValue("@deliverymanid", DBNull.Value);

            conn.Open();
            parcel.ParcelID = (int)cmd.ExecuteScalar();
            conn.Close();
            return parcel;
        }

        public bool Update(List<int> parcelInfo)
        {
            if (parcelInfo.Count < 2)
            {
                return false;
            }

            int parcelID = parcelInfo[0];
            int deliveryStatus = parcelInfo[1];

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandText = @"UPDATE parcel SET DeliveryStatus = @deliveryStatus WHERE parcelID = @parcelID";
                cmd.Parameters.AddWithValue("@parcelID", parcelID);
                cmd.Parameters.AddWithValue("@deliveryStatus", deliveryStatus);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            return true;
        }

        public List<ParcelWithDelvHist> GetSpecifiedParcel(int? parcelID, string? CustomerName)
        {
            List<ParcelWithDelvHist> ParcelList = new();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "";
            if( parcelID != null &&  CustomerName != "") 
            {
                cmd.CommandText = @"SELECT * FROM Parcel WHERE ((SenderName = @MemberName) or (ReceiverName = @MemberName)) and (ParcelID = @parcelID)";
                cmd.Parameters.AddWithValue("@MemberName", CustomerName);
                cmd.Parameters.AddWithValue("@ParcelID", parcelID);
            }
            else if (parcelID == null)
            {
                cmd.CommandText = @"SELECT * FROM Parcel WHERE (SenderName = @MemberName) or (ReceiverName = @MemberName)";
                cmd.Parameters.AddWithValue("@MemberName", CustomerName);
            }
            else if (CustomerName == "")
            {

                cmd.CommandText = @"SELECT * FROM Parcel WHERE (ParcelID = @parcelID)";
                cmd.Parameters.AddWithValue("@ParcelID", parcelID);
            }

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ParcelList.Add(
                    new ParcelWithDelvHist
                    {
                        ParcelID = reader.GetInt32(0),
                        ItemDescription = reader.GetString(1),
                        SenderName = reader.GetString(2),
                        SenderTelNo = reader.GetString(3),
                        ReceiverName = reader.GetString(4),
                        ReceiverTelNo = reader.GetString(5),
                        DeliveryAddress = reader.GetString(6),
                        FromCity = reader.GetString(7),
                        FromCountry = reader.GetString(8),
                        ToCity = reader.GetString(9),
                        ToCountry = reader.GetString(10),
                        ParcelWeight = reader.GetDouble(11),
                        DeliveryCharge = reader.GetDecimal(12),
                        Currency = reader.GetString(13),
                        TargetDeliveryDate = reader.GetDateTime(14),
                        DeliveryStatus = reader.GetString(15),

                        DeliveryManID = !reader.IsDBNull(16) ?
                                       reader.GetInt32(16) : (int?)null


                    });
                }
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return ParcelList;
        }
        public List<Parcel> getUnassignedparcellist(int parcelID)
        {
            SqlCommand cmd = conn.CreateCommand();
            if (parcelID > 0)
            {
                cmd.CommandText = @"SELECT * FROM Parcel WHERE ParcelID = @parcelID and (Deliverystatus = 4 or DeliverymanID is NULL)";
                cmd.Parameters.AddWithValue("@parcelID", parcelID);
            }
            else 
            {
                cmd.CommandText = @"Select * FROM parcel 
                                    where Deliverystatus = 4 or DeliverymanID is NULL";
            }
            ;
            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();

            List<Parcel> ParcelList = new List<Parcel>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ParcelList.Add(
                    new Parcel
                    {
                        ParcelID = reader.GetInt32(0),
                        ItemDescription = reader.GetString(1),
                        SenderName = reader.GetString(2),
                        SenderTelNo = reader.GetString(3),
                        ReceiverName = reader.GetString(4),
                        ReceiverTelNo = reader.GetString(5),
                        DeliveryAddress = reader.GetString(6),
                        FromCity = reader.GetString(7),
                        FromCountry = reader.GetString(8),
                        ToCity = reader.GetString(9),
                        ToCountry = reader.GetString(10),
                        ParcelWeight = reader.GetDouble(11),
                        DeliveryCharge = reader.GetDecimal(12),
                        Currency = reader.GetString(13),
                        TargetDeliveryDate = reader.GetDateTime(14),
                        DeliveryStatus = reader.GetString(15),

                        DeliveryManID = !reader.IsDBNull(16) ?
                                       reader.GetInt32(16) : (int?)null


                    });
                }
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return ParcelList;
        }

        public int validateworkload(int staffID) 
        {
            SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = @"select * from parcel WHERE deliverymanID = @staffID and Deliverystatus not in (0,2,3,4)";
                cmd.Parameters.AddWithValue("@staffID", staffID);

            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();

            List<Parcel> ParcelList = new List<Parcel>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    ParcelList.Add(
                    new Parcel
                    {
                        ParcelID = reader.GetInt32(0),
                        ItemDescription = reader.GetString(1),
                        SenderName = reader.GetString(2),
                        SenderTelNo = reader.GetString(3),
                        ReceiverName = reader.GetString(4),
                        ReceiverTelNo = reader.GetString(5),
                        DeliveryAddress = reader.GetString(6),
                        FromCity = reader.GetString(7),
                        FromCountry = reader.GetString(8),
                        ToCity = reader.GetString(9),
                        ToCountry = reader.GetString(10),
                        ParcelWeight = reader.GetDouble(11),
                        DeliveryCharge = reader.GetDecimal(12),
                        Currency = reader.GetString(13),
                        TargetDeliveryDate = reader.GetDateTime(14),
                        DeliveryStatus = reader.GetString(15),

                        DeliveryManID = !reader.IsDBNull(16) ?
                                       reader.GetInt32(16) : (int?)null


                    });
                }
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return ParcelList.Count();
        }

        public bool AssignParcel(int staffID, int parcelID)
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandText = @"UPDATE parcel SET DeliveryStatus = 1, DeliveryManID = @staffID WHERE parcelID = @parcelID";
                cmd.Parameters.AddWithValue("@parcelID", parcelID);
                cmd.Parameters.AddWithValue("@staffID", @staffID);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            return true;
        }


    }


}

