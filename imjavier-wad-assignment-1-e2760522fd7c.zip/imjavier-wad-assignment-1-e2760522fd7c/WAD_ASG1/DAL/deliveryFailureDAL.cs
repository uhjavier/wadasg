﻿using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using WAD_ASG1.Models;

namespace WAD_ASG1.DAL
{
    public class deliveryFailureDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public deliveryFailureDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<DeliveryFailure> GetAllDeliveryFailure()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM DeliveryFailure ORDER BY ReportID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<DeliveryFailure> DeliveryFailureList = new List<DeliveryFailure>();
            while (reader.Read())
            {
                DeliveryFailureList.Add(
                new DeliveryFailure
                {
                    ReportID = reader.GetInt32(0),
                    ParcelID = reader.GetInt32(1),
                    DeliveryManID = reader.GetInt32(2),
                    FailureType = reader.GetString(3),
                    Description = reader.GetString(4),
                    StationMgrID = reader.GetInt32(5),
                    FollowUpAction = reader.GetString(6),
                    DateCreated = reader.GetDateTime(7)
                    
                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return DeliveryFailureList;
        }
        public DeliveryFailure Add(DeliveryFailure deliveryFailure)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO deliveryfailure (ParcelID, DeliveryManID, FailureType, Description, StationMgrID, FollowUpAction, DateCreated) 
                                OUTPUT INSERTED.ReportID
                                VALUES(@ParcelID, @DeliveryManID, @FailureType, @Description, @StationMgrID, @FollowUpAction, GETDATE())";

            cmd.Parameters.AddWithValue("ParcelID", deliveryFailure.ParcelID);
            cmd.Parameters.AddWithValue("DeliveryManID", deliveryFailure.DeliveryManID);
            cmd.Parameters.AddWithValue("Description", deliveryFailure.Description);
            cmd.Parameters.AddWithValue("FailureType", deliveryFailure.FailureType);
            cmd.Parameters.AddWithValue("StationMgrID", deliveryFailure.StationMgrID ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("FollowUpAction", deliveryFailure.FollowUpAction ?? (object)DBNull.Value);
            SqlCommand cmd2 = conn.CreateCommand();
            cmd2.CommandText = @"UPDATE parcel SET DeliveryStatus = 4 WHERE parcelID = @parcelID";
            cmd2.Parameters.AddWithValue("parcelID", deliveryFailure.ParcelID);
            conn.Open();
            deliveryFailure.ReportID = (int)cmd.ExecuteScalar();
            cmd2.ExecuteNonQuery();
            conn.Close();
           

            return deliveryFailure;

        }


    }
}

