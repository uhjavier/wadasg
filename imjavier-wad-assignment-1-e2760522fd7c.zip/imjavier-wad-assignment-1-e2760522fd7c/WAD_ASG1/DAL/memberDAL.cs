﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WAD_ASG1.Models;

namespace WAD_ASG1.DAL
{

    public class memberDAL
    {

        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public memberDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<Member> GetAllMember()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM Member ORDER BY MemberID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<Member> MemberList = new List<Member>();
            while (reader.Read())
            {
                MemberList.Add(
                new Member
                {
                    MemberId = reader.GetInt32(0),

                    MemberName = reader.GetString(1),
                    Salutation = reader.GetString(2),
                    TelNo = reader.GetString(3),
                    EmailAddr = reader.GetString(4),
                    BirthDate = reader.GetDateTime(6),
                    City = reader.GetString(7),
                    Country = reader.GetString(8)

                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return MemberList;
        }
        public bool Login(string emailAddr, string password)
        {
            bool authenticated = false;
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM Member";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end
            while (reader.Read())
            {
                // Convert email address to lowercase for comparison
                // Password comparison is case-sensitive
                if ((reader.GetString(4).ToLower() == emailAddr.ToLower()) &&
                (reader.GetString(5) == password))
                {
                    authenticated = true;
                    break; // Exit the while loop
                }
            }
            return authenticated;
        }

        public Member GetMemberDetails(string loginID)
        {
            Member member = new Member();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT * FROM Member WHERE EmailAddr = @SelectedloginID";
            cmd.Parameters.AddWithValue("@SelectedloginID", loginID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                member.MemberId = reader.GetInt32(0);
                member.MemberName = reader.GetString(1);
                member.Salutation = reader.GetString(2);
                member.TelNo = reader.GetString(3);
                member.EmailAddr = reader.GetString(4);
                member.BirthDate = reader.GetDateTime(6);
                member.City = reader.GetString(7);
                member.Country = reader.GetString(8);

            }
            reader.Close();
            conn.Close();
            return member;

        }

        public int Add(Member member)
        {
            SqlCommand cmd = conn.CreateCommand();  
            cmd.CommandText = @"INSERT INTO Member (Name, Salutation, TelNo, EmailAddr, Password, BirthDate, City, Country) 
                                OUTPUT INSERTED.MemberID 
                                VALUES(@name, @salutation, @telno, @emailaddr, @password, @birthdate, @city, @country)";
                        
            cmd.Parameters.AddWithValue("@name", member.MemberName);
            cmd.Parameters.AddWithValue("@salutation", member.Salutation);
            cmd.Parameters.AddWithValue("@telno", member.TelNo);
            cmd.Parameters.AddWithValue("@emailaddr", member.EmailAddr);
            cmd.Parameters.AddWithValue("@password", member.Password);
            cmd.Parameters.AddWithValue("@birthdate", member.BirthDate);
            cmd.Parameters.AddWithValue("@city", member.City);
            cmd.Parameters.AddWithValue("@country", member.Country);
            conn.Open();
            member.MemberId = (int)cmd.ExecuteScalar();
            conn.Close();
            return member.MemberId;
        }

        // It is not working
        public bool IsEmailExist(string email)
        {
            bool emailFound = false;
            //Create a SqlCommand object and specify the SQL statement 
            //to get a staff record with the email address to be validated
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT EmailAddr FROM Member WHERE EmailAddr =@selectedEmail";
            cmd.Parameters.AddWithValue("@selectedEmail", email);
            //Open a database connection and execute the SQL statement
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            { //Records found
                while (reader.Read())
                {
                    if (reader.GetString(0) != email)
                        //The email address is used by another member
                        emailFound = false;
                    else
                        emailFound = true;
                }
            }
            else
            { //No record
                emailFound = false; // The email address given does not exist
            }
            reader.Close();
            conn.Close();
            return emailFound;
        }
       
        public bool ExecuteQuery(string sql)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            return true;
        }

    }




}
