﻿using System.Data.SqlClient;
using WAD_ASG1.Models;

namespace WAD_ASG1.DAL
{
    public class staffDAL
    {

        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public staffDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<Staff> GetAllStaff()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM Staff ORDER BY StaffID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<Staff> staffList = new List<Staff>();
            while (reader.Read())
            {
                staffList.Add(
                new Staff
                {
                    StaffID = reader.GetInt32(0), //0: 1st column
                    StaffLoginID = reader.GetString(2),
                    StaffName = reader.GetString(1), //1: 2nd column
                    Appointment = reader.GetString(4), //2: 3rd column
                    OfficeTelNo = reader.GetString(5), //3: 4th column
                    Location = reader.GetString(6)
                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return staffList;
        }
        public bool Login(string loginId, string password)
        {
            bool authenticated = false;
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM Staff";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end
            while (reader.Read())
            {
                // Convert email address to lowercase for comparison
                // Password comparison is case-sensitive
                if ((reader.GetString(2).ToLower() == loginId.ToLower()) &&
                (reader.GetString(3) == password))
                {
                    authenticated = true;
                    break; // Exit the while loop
                }
            }
            reader.Close();
            conn.Close();
            return authenticated;
        }

        public Staff GetStaffDetails(string loginId)
        {
            Staff staff = new Staff();
            SqlCommand cmd = conn.CreateCommand();
            
            cmd.CommandText = @"SELECT * FROM Staff WHERE loginID = @loginId";
            cmd.Parameters.AddWithValue("@loginId", loginId);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                staff.StaffID = reader.GetInt32(0);
                staff.StaffName = reader.GetString(1);
                staff.StaffLoginID = reader.GetString(2);
                staff.Appointment = reader.GetString(4);
                staff.OfficeTelNo = reader.GetString(5);
                staff.Location = reader.GetString(6);

            }
            reader.Close();
            conn.Close();

            return staff;
        }

        public List<Staff> getAppointedStaff(string appointment) 
        {
            List<Staff> list = new List<Staff>();
            SqlCommand cmd = conn.CreateCommand();
            if (appointment == "" ) {
                return list;
            }
            cmd.CommandText = @"SELECT * FROM Staff WHERE appointment = @appointment ";
            cmd.Parameters.AddWithValue("@appointment", appointment);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(
                new Staff
                {
                    StaffID = reader.GetInt32(0), //0: 1st column
                    StaffLoginID = reader.GetString(2),
                    StaffName = reader.GetString(1), //1: 2nd column
                    Appointment = reader.GetString(4), //2: 3rd column
                    OfficeTelNo = reader.GetString(5), //3: 4th column
                    Location = reader.GetString(6)
                }
                );
            }
            reader.Close ();

            conn.Close();

            return list;
        
        }
    }




}
