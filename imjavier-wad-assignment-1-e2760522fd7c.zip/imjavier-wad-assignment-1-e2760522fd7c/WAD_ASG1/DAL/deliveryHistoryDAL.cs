﻿using System.Data.SqlClient;
using WAD_ASG1.Models;

namespace WAD_ASG1.DAL
{
    public class deliveryHistoryDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;
        //Constructor
        public deliveryHistoryDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<DeliveryHistory> GetAllDeliveryHistory()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM DeliveryHistory ORDER BY RecordID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<DeliveryHistory> DeliveryHistoryList = new List<DeliveryHistory>();
            while (reader.Read())
            {
                DeliveryHistoryList.Add(
                new DeliveryHistory
                {
                    RecordID = reader.GetInt32(0),
                    ParcelID = reader.GetInt32(1),
                    Description = reader.GetString(2)
                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return DeliveryHistoryList;
        }

        public bool Add(DeliveryHistory deliveryHistory)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO DeliveryHistory (ParcelID, Description) 
                                OUTPUT INSERTED.RecordID
                                VALUES(@parcelid, @description)";

            cmd.Parameters.AddWithValue("@parcelid", deliveryHistory.ParcelID);
            cmd.Parameters.AddWithValue("@description", deliveryHistory.Description);
            conn.Open();
            deliveryHistory.RecordID = (int)cmd.ExecuteScalar();
            conn.Close();
            return true;
        }

        public List<ParcelWithDelvHist> getDeliveryHistory(int parcelID)
        {
            List<ParcelWithDelvHist> deliveryHistories = new List<ParcelWithDelvHist>();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"Select * From deliveryhistory Where ParcelID = @ParcelID";
            cmd.Parameters.AddWithValue("@ParcelID", parcelID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                deliveryHistories.Add(new ParcelWithDelvHist
                {
                    RecordID = reader.GetInt32(0),
                    ParcelID = reader.GetInt32(1),
                    Description = reader.GetString(2)
                });

            }
            reader.Close();
            conn.Close();
            return deliveryHistories;
        }
    }
}
