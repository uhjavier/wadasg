﻿using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using WAD_ASG1.Models;

namespace WAD_ASG1.DAL
{
    public class feedbackEnquiryDAL
    {
        private IConfiguration Configuration { get; }
        private SqlConnection conn;

        //Constructor
        public feedbackEnquiryDAL()
        {
            //Read ConnectionString from appsettings.json file
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "NPCSConnectionStrings");
            //Instantiate a SqlConnection object with the
            //Connection String read.
            conn = new SqlConnection(strConn);
        }
        public List<FeedbackEnquiry> GetAllFeedbackEnquiry()
        {
            //Create a SqlCommand object from connection object
            SqlCommand cmd = conn.CreateCommand();
            //Specify the SELECT SQL statement
            cmd.CommandText = @"SELECT * FROM FeedbackEnquiry ORDER BY FeedbackEnquiryID";
            //Open a database connection
            conn.Open();
            //Execute the SELECT SQL through a DataReader
            SqlDataReader reader = cmd.ExecuteReader();
            //Read all records until the end, save data into a staff list
            List<FeedbackEnquiry> FeedbackEnquiryList = new List<FeedbackEnquiry>();
            while (reader.Read())
            {
                FeedbackEnquiryList.Add(
                new FeedbackEnquiry
                {
                    FeedbackEnquiryID = reader.GetInt32(0),
                    MemberID = (int)reader.GetInt32(1),
                    Content = reader.GetString(2),
                    DateTimePosted = reader.GetDateTime(3),
                    StaffID = !reader.IsDBNull(4) ?
                                           reader.GetInt32(4) : (int?)null,
                    Response = !reader.IsDBNull(5) ?
                                       reader.GetString(5) : (string?)null,
                    Status = reader.GetString(6)

                }
                );
            }
            //Close DataReader
            reader.Close();
            //Close the database connection
            conn.Close();
            return FeedbackEnquiryList;
        }
        public void Add(FeedbackEnquiry MemberFeed)
        {
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO FeedbackEnquiry (MemberID, Content, DateTimePosted, StaffID, Response, Status) 
                                OUTPUT INSERTED.FeedBackEnquiryID
                                VALUES(@MemberID, @Content, @DateTimePosted, @StaffID, @Response, @Status)";
            cmd.Parameters.AddWithValue("@MemberID", MemberFeed.MemberID);
            cmd.Parameters.AddWithValue("@Content", MemberFeed.Content);
            cmd.Parameters.AddWithValue("@DateTimePosted", MemberFeed.DateTimePosted);
            cmd.Parameters.AddWithValue("@StaffID", MemberFeed.StaffID ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@Response", MemberFeed.Response ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@Status", MemberFeed.Status);
            conn.Open();
            MemberFeed.MemberID = (int)cmd.ExecuteScalar();
            conn.Close();
        }

        public List<FeedbackEnquiry> GetMemberFeedbackEnquiry(int memberID)
        {
            FeedbackEnquiry feedbackEnquiry = new FeedbackEnquiry();
            List<FeedbackEnquiry> enquiryList = new List<FeedbackEnquiry>();
            SqlCommand cmd = conn.CreateCommand();

            cmd.CommandText = @"SELECT * FROM FeedbackEnquiry WHERE MemberID = @SelectedloginID";
            cmd.Parameters.AddWithValue("@SelectedloginID", memberID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    enquiryList.Add(
                    new FeedbackEnquiry
                    {
                        FeedbackEnquiryID = reader.GetInt32(0),
                        MemberID = (int)reader.GetInt32(1),
                        Content = reader.GetString(2),
                        DateTimePosted = reader.GetDateTime(3),
                        StaffID = !reader.IsDBNull(4) ?
                                           reader.GetInt32(4) : (int?)null,
                        Response = !reader.IsDBNull(5) ?
                                       reader.GetString(5) : (string?)null,
                        Status = reader.GetString(6)
                    });
                }
            }
            reader.Close();
            conn.Close();
            return enquiryList;
        }

        public bool Update(int FeedID, int? StaffID ,  string? Response)
        {

            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE FeedbackEnquiry SET status = 1, Response = @Response, StaffID = @StaffID WHERE FeedbackEnquiryID = @FeedID";

            conn.Open();
            cmd.Parameters.AddWithValue("@FeedID", FeedID);
            if(Response != null)
            {
                cmd.Parameters.AddWithValue("@Response", Response);
            }
            else
            {
                cmd.Parameters.AddWithValue("@Response", DBNull.Value);
            }

            cmd.Parameters.AddWithValue("@StaffID", StaffID);
            cmd.ExecuteNonQuery();
            conn.Close();
            return true;
        }
    }
}


