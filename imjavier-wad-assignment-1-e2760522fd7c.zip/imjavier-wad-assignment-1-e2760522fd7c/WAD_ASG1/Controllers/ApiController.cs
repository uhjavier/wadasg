﻿using Microsoft.AspNetCore.Mvc;
using WAD_ASG1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography.X509Certificates;
using WAD_ASG1.DAL;
using WAD_ASG1.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Newtonsoft.Json;
using System.Configuration;
using System.Net.Http;

namespace WAD_ASG1.Controllers
{
    public class ApiController : Controller
    {

        private WeatherForecast weatherForecast = new WeatherForecast();
        private WeatherForecast2hr weatherForecast2hr = new WeatherForecast2hr();
        public async Task<combinedForecast> combinedForecast()
        {

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://api.data.gov.sg/v1//environment/");
            HttpResponseMessage response = await client.GetAsync("24-hour-weather-forecast");
            HttpResponseMessage response2 = await client.GetAsync("2-hour-weather-forecast");


            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                string data2 = await response2.Content.ReadAsStringAsync();
                weatherForecast = JsonConvert.DeserializeObject<WeatherForecast>(data);
                weatherForecast2hr = JsonConvert.DeserializeObject<WeatherForecast2hr>(data2);
                var CombinedForecast = new combinedForecast
                {
                    weatherForecast24hr = weatherForecast,
                    weatherForecast2hr = weatherForecast2hr
                };

                foreach (var item in weatherForecast.Items)
                {
                    Console.WriteLine(item);
                }
                return CombinedForecast;
            }
            else
            {
                return new combinedForecast();
            }
        }

        public async Task<TrafficIncident> trafficInfo()
        {
            TrafficIncident TrafficIncidentInfo = new TrafficIncident();
            string apiKey = "JoFZsCgCSnK1Sh82sRwIiA=="; //NOTE PLEASE CALL THE API WITH THIS KEY SPARINGLY I HAVE LIMITED RATES AND IT IS BEING MONITORED BY LTA PLS
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://datamall2.mytransport.sg/ltaodataservice/");
            client.DefaultRequestHeaders.Add("Accountkey", apiKey);
            HttpResponseMessage response = await client.GetAsync("TrafficIncidents");
            if (response.IsSuccessStatusCode)
            {
                // Read and deserialize
                string responseData = await response.Content.ReadAsStringAsync();
                TrafficIncidentInfo = JsonConvert.DeserializeObject<TrafficIncident>(responseData);
                return TrafficIncidentInfo;
            }
            else
            {

                return TrafficIncidentInfo;
            }
        }
    }


}
