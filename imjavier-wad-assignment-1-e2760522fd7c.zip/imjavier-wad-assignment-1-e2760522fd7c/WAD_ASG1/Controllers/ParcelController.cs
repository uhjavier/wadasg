﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Primitives;
using System.Transactions;
using WAD_ASG1.DAL;
using WAD_ASG1.Models;

namespace WAD_ASG1.Controllers
{
    public class ParcelController : Controller
    {
        private parcelDAL parcelDAL = new parcelDAL();
        // GET: CreateParcel
        private List<Parcel> parcelDetails = new();
        private deliveryHistoryDAL deliveryHistoryDAL = new deliveryHistoryDAL();
        private feedbackEnquiryDAL feedbackEnquiryDAL = new feedbackEnquiryDAL();
        private staffDAL staffDAL = new staffDAL();
        private shippingRateDAL shippingRateDAL = new();
        private paymentTransactionDAL paymentTransactionDAL = new paymentTransactionDAL();

        private PaymentTransaction paymentTransactionsDAL = new PaymentTransaction();

        public ParcelController()
        {
            ViewData["Currency"] = GetCurrency();
            ViewData["Countries"] = GetCountry();
            ViewData["Cities"] = GetCity();
        }
        public ActionResult Index()
        {
            return View();
        }

        // GET: CreateParcel/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: CreateParcel/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CreateParcel/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CreateParcel/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: CreateParcel/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CreateParcel/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: CreateParcel/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public List<Parcel> SelectedParcelDetails(IFormCollection ParcelData)
        {

            int? deliverymanID;
            ViewData["ShowDetails"] = true;
            if (ParcelData["deliveryManId"] != "")
            {
                deliverymanID = Convert.ToInt32(ParcelData["deliveryManId"]);
            }
            else
            {
                deliverymanID = null;
            }
            Parcel parcel = new Parcel
            {
                ParcelID = Convert.ToInt32(ParcelData["parcelId"]),
                ItemDescription = ParcelData["itemDescription"],
                SenderName = ParcelData["senderName"],
                SenderTelNo = ParcelData["senderTelNo"],
                ReceiverName = ParcelData["receiverName"],
                ReceiverTelNo = ParcelData["receiverTelNo"],
                DeliveryAddress = ParcelData["deliveryAddress"],
                FromCity = ParcelData["fromCity"],
                ToCountry = ParcelData["toCountry"],
                FromCountry = ParcelData["fromCountry"],
                ToCity = ParcelData["toCity"],
                ParcelWeight = Convert.ToDouble(ParcelData["parcelWeight"]),
                DeliveryCharge = Convert.ToDecimal(ParcelData["deliveryCharge"]),
                Currency = ParcelData["currency"],
                TargetDeliveryDate = Convert.ToDateTime(ParcelData["targetDeliveryDate"]),
                DeliveryStatus = ParcelData["deliveryStatus"],
                DeliveryManID = deliverymanID
            };
            if (parcel != null)
            {
                if (parcel.DeliveryStatus == "0")
                {
                    parcel.DeliveryStatus = "Pending Delivery";
                }
                else if (parcel.DeliveryStatus == "1")
                {
                    parcel.DeliveryStatus = "Delivery to destination in progress";
                }
                else if (parcel.DeliveryStatus == "2")
                {
                    parcel.DeliveryStatus = "Delivery to airport in progress";
                }
                else if (parcel.DeliveryStatus == "3")
                {
                    parcel.DeliveryStatus = "Delivery completed";
                }
                else if (parcel.DeliveryStatus == "4")
                {
                    parcel.DeliveryStatus = "Delivery has failed. Delivery is schedule to another day.";
                }
            }
            parcelDetails.Add(parcel);

            return parcelDetails;

        }

        public IActionResult SearchParcel()
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Station Manager")
            {
                return RedirectToAction("Index", "Staff");
            }
            return View();
        }
        [HttpPost]
        public IActionResult SearchCustomerParcel(IFormCollection formData)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Station Manager")
            {
                return RedirectToAction("Index", "Staff");
            }
            int ParcelIDparse;
            int? parcelID;
            if (int.TryParse((string?)formData["ParcelID"], out ParcelIDparse) || formData["ParcelID"] == "")
            {
                if (formData["ParcelID"] == "")
                {
                    parcelID = null;
                }
                else
                {
                    parcelID = ParcelIDparse;
                }
            }
            else
            {
                TempData["ErrMsg"] = "Please enter a valid number";
                return View("SearchParcel");
            }

            string? CustomerName = Convert.ToString(formData["CustomerName"]);
            List<ParcelWithDelvHist> parcelDetails = parcelDAL.GetSpecifiedParcel(parcelID, CustomerName);
            if (parcelDetails.Count > 0)
            {
                foreach (var parcel in parcelDetails)
                {
                    List<ParcelWithDelvHist> deliveryhistorylist = deliveryHistoryDAL.getDeliveryHistory(parcel.ParcelID);
                    parcel.Description = deliveryhistorylist.Last().Description;
                    if (parcel.DeliveryStatus == "0")
                    {
                        parcel.DeliveryStatus = "Pending Delivery";
                    }
                    else if (parcel.DeliveryStatus == "1")
                    {
                        parcel.DeliveryStatus = "Delivery to destination in progress";
                    }
                    else if (parcel.DeliveryStatus == "2")
                    {
                        parcel.DeliveryStatus = "Delivery to airport in progress";
                    }
                    else if (parcel.DeliveryStatus == "3")
                    {
                        parcel.DeliveryStatus = "Delivery completed";
                    }
                    else if (parcel.DeliveryStatus == "4")
                    {
                        parcel.DeliveryStatus = "Delivery has failed. Delivery is scheduled to another day.";
                    }

                }
            }
            ViewData["SearchResults"] = true;
            return View("SearchParcel", parcelDetails);
        }

        public IActionResult AssignParcel(IFormCollection formdata)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Station Manager")
            {
                return RedirectToAction("Index", "Staff");
            }
            int parcelID;
            List<Parcel> UnassignedParcelList = new List<Parcel>();
            if (formdata == null)
            {
                parcelID = 0;
                UnassignedParcelList = parcelDAL.getUnassignedparcellist(parcelID);
                foreach (Parcel parcel in UnassignedParcelList)
                {
                    if (parcel.DeliveryStatus == "0")
                    {
                        parcel.DeliveryStatus = "Pending Delivery";
                    }
                    else if (parcel.DeliveryStatus == "1")
                    {
                        parcel.DeliveryStatus = "Delivery to destination in progress";
                    }
                    else if (parcel.DeliveryStatus == "2")
                    {
                        parcel.DeliveryStatus = "Delivery to airport in progress";
                    }
                    else if (parcel.DeliveryStatus == "3")
                    {
                        parcel.DeliveryStatus = "Delivery completed";
                    }
                    else if (parcel.DeliveryStatus == "4")
                    {
                        parcel.DeliveryStatus = "Delivery has failed. Delivery is scheduled to another day.";
                    }
                }
                return View("AssignParcel", UnassignedParcelList);
            }
            if (int.TryParse(formdata["ParcelID"], out parcelID))
            {
                parcelID = Convert.ToInt32(formdata["ParcelID"]);
                UnassignedParcelList = parcelDAL.getUnassignedparcellist(parcelID);
                foreach (Parcel parcel in UnassignedParcelList)
                {
                    if (parcel.DeliveryStatus == "0")
                    {
                        parcel.DeliveryStatus = "Pending Delivery";
                    }
                    else if (parcel.DeliveryStatus == "1")
                    {
                        parcel.DeliveryStatus = "Delivery to destination in progress";
                    }
                    else if (parcel.DeliveryStatus == "2")
                    {
                        parcel.DeliveryStatus = "Delivery to airport in progress";
                    }
                    else if (parcel.DeliveryStatus == "3")
                    {
                        parcel.DeliveryStatus = "Delivery completed";
                    }
                    else if (parcel.DeliveryStatus == "4")
                    {
                        parcel.DeliveryStatus = "Delivery has failed. Delivery is scheduled to another day.";
                    }
                }
                return View("AssignParcel", UnassignedParcelList);
            }
            else
            {
                parcelID = 0;
                UnassignedParcelList = parcelDAL.getUnassignedparcellist(parcelID);
                foreach (Parcel parcel in UnassignedParcelList)
                {
                    if (parcel.DeliveryStatus == "0")
                    {
                        parcel.DeliveryStatus = "Pending Delivery";
                    }
                    else if (parcel.DeliveryStatus == "1")
                    {
                        parcel.DeliveryStatus = "Delivery to destination in progress";
                    }
                    else if (parcel.DeliveryStatus == "2")
                    {
                        parcel.DeliveryStatus = "Delivery to airport in progress";
                    }
                    else if (parcel.DeliveryStatus == "3")
                    {
                        parcel.DeliveryStatus = "Delivery completed";
                    }
                    else if (parcel.DeliveryStatus == "4")
                    {
                        parcel.DeliveryStatus = "Delivery has failed. Delivery is scheduled to another day.";
                    }
                }
                return View("AssignParcel", UnassignedParcelList);
            }

        }
        [HttpPost]
        public IActionResult SearchUnassignedParcel(IFormCollection formdata)
        {
            return AssignParcel(formdata);
        }

        [HttpPost]
        public IActionResult AssignDeliveryMan(IFormCollection formdata)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Station Manager")
            {
                return RedirectToAction("Index", "Staff");
            }
            //get list of staff under deliveryman
            List<Staff> stafflist = staffDAL.getAppointedStaff("Delivery Man");
            ViewData["ParcelID"] = formdata["parcelId"];
            //check the deliveryman workload
            foreach (Staff staff in stafflist)
            {
                string staffinfo = staff.StaffID.ToString() + staff.StaffName;
                int parcelcount = parcelDAL.validateworkload(staff.StaffID);
                ViewData[staffinfo] = parcelcount;
            }

            return View(stafflist);
        }
        public IActionResult AssignParcelToDelvMan(IFormCollection formData)
        {
            int staffID = Convert.ToInt32(formData["staffID"]);
            int parcelID = Convert.ToInt32(formData["ParcelID"]);
            bool isAssigned = parcelDAL.AssignParcel(staffID, parcelID);
            string? staffUser = HttpContext.Session.GetString("loginID");
            string DateCreated = DateTime.Now.ToString("dd MMM yyyy hh:mm tt");
            string deliveryDesc = $"Received by {staffUser} on {DateCreated}";
            DeliveryHistory deliveryHistory = new DeliveryHistory()
            {
                Description = deliveryDesc,
                ParcelID = parcelID
            };
            ViewData["SubmissionResults"] = true;
            bool isAdded = deliveryHistoryDAL.Add(deliveryHistory);
            IFormCollection emptyform = new FormCollection(new Dictionary<string, StringValues>());
            return AssignParcel(emptyform);
        }


        private List<SelectListItem> GetCurrency()
        {
            List<SelectListItem> currencyList = new List<SelectListItem>();
            currencyList.Add(new SelectListItem
            {
                Value = "SGD",
                Text = "Singapore Dollar (SGD)"
            });
            currencyList.Add(new SelectListItem
            {
                Value = "EUR",
                Text = "Euro (EUR)"
            });
            currencyList.Add(new SelectListItem
            {
                Value = "USD",
                Text = "United States Dollar (USD)"
            });
            currencyList.Add(new SelectListItem
            {
                Value = "CNY",
                Text = "Chinese Yuan (CNY)"
            });
            return currencyList;
        }

        private List<SelectListItem> GetCity()
        {
            List<SelectListItem> cityList = new List<SelectListItem>();
            cityList.Add(new SelectListItem
            {
                Value = "Singapore",
                Text = "Singapore"
            });
            cityList.Add(new SelectListItem
            {
                Value = "Kuala Lumpur",
                Text = "Kuala Lumpur"
            });
            cityList.Add(new SelectListItem
            {
                Value = "Hong Kong",
                Text = "Hong Kong"
            });
            cityList.Add(new SelectListItem
            {
                Value = "Beijing",
                Text = "Beijing"
            });
            cityList.Add(new SelectListItem
            {
                Value = "Tokyo",
                Text = "Tokyo"
            });
            cityList.Add(new SelectListItem
            {
                Value = "Sydney",
                Text = "Sydney"
            });
            cityList.Add(new SelectListItem
            {
                Value = "New York",
                Text = "New York"
            });
            cityList.Add(new SelectListItem
            {
                Value = "San Francisco",
                Text = "San Francisco"
            });
            cityList.Add(new SelectListItem
            {
                Value = "Paris",
                Text = "Paris"
            });
            cityList.Add(new SelectListItem
            {
                Value = "London",
                Text = "London"
            });

            return cityList;
        }
        private IActionResult GetCountryOptions(string city)
        {
            List<SelectListItem> countryList = GetCountry();
            return Json(countryList);
        }
        private List<SelectListItem> GetCountry()
        {
            List<SelectListItem> countryList = new List<SelectListItem>();

            countryList.Add(new SelectListItem
            {
                Value = "Singapore",
                Text = "Singapore"
            });
            countryList.Add(new SelectListItem
            {
                Value = "Malaysia",
                Text = "Malaysia"
            });

            countryList.Add(new SelectListItem
            {
                Value = "China",
                Text = "China"
            });

            countryList.Add(new SelectListItem
            {
                Value = "USA",
                Text = "USA"
            });


            countryList.Add(new SelectListItem
            {
                Value = "Australia",
                Text = "Australia"
            });


            countryList.Add(new SelectListItem
            {
                Value = "France",
                Text = "France"
            });


            countryList.Add(new SelectListItem
            {
                Value = "UK",
                Text = "UK"
            });

            return countryList;
        }


        private List<SelectListItem> GetPaymentChoice()
        {
            List<SelectListItem> paymentChoiceList = new List<SelectListItem>();
            paymentChoiceList.Add(new SelectListItem
            {
                Value = "Cash",
                Text = "Cash"
            });
            paymentChoiceList.Add(new SelectListItem
            {
                Value = "Cash Voucher",
                Text = "Cash Voucher"
            });
            paymentChoiceList.Add(new SelectListItem
            {
                Value = "Cash + Cash Voucher",
                Text = "Cash + Cash Voucher"
            });

            return paymentChoiceList;
        }
        public IActionResult CreateParcel(IFormCollection formData)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Front Office Staff")
            {
                return RedirectToAction("Index", "Staff");
            }
            ViewData["City"] = GetCity();
            ViewData["Currency"] = GetCurrency();
            ViewData["Countries"] = GetCountry();
            ViewData["Cities"] = GetCity();
            Parcel parcel = new Parcel();
            //DeliveryHistory deliveryHistory = new DeliveryHistory();
            if (formData.Count != 0)
            {
                parcel.ItemDescription = formData["ItemDescription"];
                parcel.SenderName = formData["SenderName"];
                parcel.SenderTelNo = formData["SenderTelNo"];
                parcel.ReceiverName = formData["ReceiverName"];
                parcel.ReceiverTelNo = formData["ReceiverTelNo"];
                parcel.DeliveryAddress = formData["DeliveryAddress"];
                parcel.FromCity = formData["FromCity"];
                parcel.FromCountry = formData["FromCountry"];
                parcel.ToCity = formData["ToCity"];
                parcel.ToCountry = formData["ToCountry"];
                parcel.Currency = formData["Currency"];
                parcel.ParcelWeight = Convert.ToDouble(formData["ParcelWeight"]);
                parcel.DeliveryManID = null;
                parcel.DeliveryStatus = "0";
                return View("Createparcel", parcel);
            }

            return View("Createparcel");
        }




        [HttpPost]
        public IActionResult ParcelInfo(IFormCollection formData)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Front Office Staff")
            {
                return RedirectToAction("Index", "Staff");
            }
            ViewData["Currency"] = GetCurrency();
            ViewData["Countries"] = GetCountry();
            ViewData["Cities"] = GetCity();
            Parcel parcel = new Parcel();
            //DeliveryHistory deliveryHistory = new DeliveryHistory();
            parcel.ItemDescription = formData["ItemDescription"];
            parcel.SenderName = formData["SenderName"];
            parcel.SenderTelNo = formData["SenderTelNo"];
            parcel.ReceiverName = formData["ReceiverName"];
            parcel.ReceiverTelNo = formData["ReceiverTelNo"];
            parcel.DeliveryAddress = formData["DeliveryAddress"];
            parcel.FromCity = formData["FromCity"];
            parcel.FromCountry = formData["FromCountry"];
            parcel.ToCity = formData["ToCity"];
            parcel.ToCountry = formData["ToCountry"];
            parcel.Currency = formData["Currency"];
            parcel.ParcelWeight = Convert.ToDouble(formData["ParcelWeight"]);
            parcel.DeliveryManID = null;
            parcel.DeliveryStatus = "0";
            // Calculate Delivery Charge           
            ShippingRates newShippingRates = shippingRateDAL.GetShippingRate(formData["ToCity"]);
            decimal deliveryCharges = newShippingRates.ShippingRate * Convert.ToDecimal(formData["ParcelWeight"]);
            decimal roundDeliveryCharges = Math.Round(deliveryCharges);
            if (roundDeliveryCharges < 5)
            {
                roundDeliveryCharges = 5;
            }
            parcel.DeliveryCharge = roundDeliveryCharges;
            int transitTime = newShippingRates.TransitTime;

            parcel.TargetDeliveryDate = DateTime.Now.AddDays(transitTime);

            return View("Confirmation", parcel);
        }

        [HttpPost]
        public ActionResult Confirm_parcel(IFormCollection formData)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Front Office Staff")
            {
                return RedirectToAction("Index", "Staff");
            }
            Parcel parcel = new Parcel();
            //DeliveryHistory deliveryHistory = new DeliveryHistory();
            parcel.ItemDescription = formData["ItemDescription"];
            parcel.SenderName = formData["SenderName"];
            parcel.SenderTelNo = formData["SenderTelNo"];
            parcel.ReceiverName = formData["ReceiverName"];
            parcel.ReceiverTelNo = formData["ReceiverTelNo"];
            parcel.DeliveryAddress = formData["DeliveryAddress"];
            parcel.FromCity = formData["FromCity"];
            parcel.FromCountry = formData["FromCountry"];
            parcel.ToCity = formData["ToCity"];
            parcel.ToCountry = formData["ToCountry"];
            parcel.Currency = formData["Currency"];
            parcel.ParcelWeight = Convert.ToDouble(formData["ParcelWeight"]);
            parcel.DeliveryManID = null;
            parcel.DeliveryStatus = "0";

            // Calculate Delivery Charge           
            ShippingRates newShippingRates = shippingRateDAL.GetShippingRate(formData["ToCity"]);
            decimal deliveryCharges = newShippingRates.ShippingRate * Convert.ToDecimal(formData["ParcelWeight"]);
            decimal roundDeliveryCharges = Math.Round(deliveryCharges);
            if (roundDeliveryCharges < 5)
            {
                roundDeliveryCharges = 5;
            }
            parcel.DeliveryCharge = roundDeliveryCharges;
            int transitTime = newShippingRates.TransitTime;
            parcel.TargetDeliveryDate = DateTime.Now.AddDays(transitTime);


            return View("Payment", parcel);
        }

        [HttpPost]
        public ActionResult Payment(IFormCollection formData)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Front Office Staff")
            {
                return RedirectToAction("Index", "Staff");
            }
            PaymentTransaction cashPayment = new PaymentTransaction();
            PaymentTransaction voucherPayment = new PaymentTransaction();
            Parcel parcel = new Parcel();
            //DeliveryHistory deliveryHistory = new DeliveryHistory();
            parcel.ItemDescription = formData["ItemDescription"];
            parcel.SenderName = formData["SenderName"];
            parcel.SenderTelNo = formData["SenderTelNo"];
            parcel.ReceiverName = formData["ReceiverName"];
            parcel.ReceiverTelNo = formData["ReceiverTelNo"];
            parcel.DeliveryAddress = formData["DeliveryAddress"];
            parcel.FromCity = formData["FromCity"];
            parcel.FromCountry = formData["FromCountry"];
            parcel.ToCity = formData["ToCity"];
            parcel.ToCountry = formData["ToCountry"];
            parcel.Currency = formData["Currency"];
            parcel.ParcelWeight = Convert.ToDouble(formData["ParcelWeight"]);
            parcel.DeliveryManID = null;
            parcel.DeliveryStatus = "0";
            // Not yet done will continue


            return View();
        }

        [HttpPost]
        public IActionResult ParcelPayment(Parcel parcel, IFormCollection paymentdetails) 
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Front Office Staff")
            {
                return RedirectToAction("Index", "Staff");
            }
            DeliveryHistory deliveryHistory = new DeliveryHistory();
            Parcel check = parcel;
            PaymentTransaction transactionCash = new PaymentTransaction();
            PaymentTransaction transactionVoucher = new PaymentTransaction();
            int cash = 0;
            int voucher = 0;
            //store parcel in db
            if (paymentdetails.Count > 0)
            {
                if(int.TryParse(paymentdetails["Cash"], out cash))
                {
                }
                if (int.TryParse(paymentdetails["Voucher"], out voucher)) { }
        
                //create paymenttransaction model
            }

            string DateCreated = DateTime.Now.ToString("dd MMM yyyy hh:mm tt");
            string StaffID = HttpContext.Session.GetString("loginID");
            string Desc = $"Received parcel by {StaffID} on {DateCreated}";
            

            using (var scope = new TransactionScope())
            {
                try
                {
                    //for delivery history
                    Parcel UpdatedParcel = parcelDAL.Add(parcel);
                    deliveryHistory.ParcelID = UpdatedParcel.ParcelID;
                    deliveryHistory.Description = Desc;

                    //for payment transaction
                    bool isAddedCash = false;
                    if (cash > 0)
                    {
                        transactionCash.ParcelID = UpdatedParcel.ParcelID;
                        transactionCash.AmtTran = cash;
                        transactionCash.Currency = UpdatedParcel.Currency;
                        transactionCash.TranType = "CASH";
                        transactionCash.TranDate = DateTime.Now;
                        isAddedCash = paymentTransactionDAL.Add(transactionCash);


                    }
                    bool isAddedVouc = false ;
                    if (voucher > 0)
                    {
                        transactionVoucher.ParcelID = UpdatedParcel.ParcelID;
                        transactionVoucher.AmtTran = voucher;
                        transactionVoucher.Currency = UpdatedParcel.Currency;
                        transactionVoucher.TranType = "VOUC";
                        transactionVoucher.TranDate = DateTime.Now;
                        isAddedVouc = paymentTransactionDAL.Add(transactionVoucher);

                    }
                    

                    bool isAdded = deliveryHistoryDAL.Add(deliveryHistory);

                    if (isAdded && (isAddedCash || isAddedVouc))
                    {
                        scope.Complete();
                        TempData["SubmissionResults"] = true;
                        TempData["SubmitResultMessage"] = "Parcel Added Successfully";
                        return RedirectToAction("Index", "Staff");
                    }

                }
                catch (Exception)
                {
                    TempData["SubmissionResults"] = true;
                    TempData["SubmitResultMessage"] = "Something went wrong, please create the parcel again";
                }


            };

            return View();
        
        }




    }
}
