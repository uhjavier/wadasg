﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using WAD_ASG1.DAL;
using WAD_ASG1.Models;


namespace WAD_ASG1.Controllers
{

    public class StaffController : Controller
    {
        private parcelDAL parcelDAL = new();
        private staffDAL staffDAL = new();
        private shippingRateDAL shippingRateDAL = new();
        private List<Parcel> parcelDetails = new List<Parcel>();
        private PaymentTransaction paymentTransactionsDAL = new PaymentTransaction();
        private deliveryHistoryDAL deliveryHistoryDAL = new();
        private WeatherForecast weatherForecast = new WeatherForecast();
        private WeatherForecast2hr weatherForecast2hr = new WeatherForecast2hr();
        // GET: StaffController
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("Role") == "Member")
            {
                return RedirectToAction("Index", "member");
            }
            else if (HttpContext.Session.GetString("Role") == null) { return RedirectToAction("Login" , "Home"); }


            if (Convert.ToBoolean(TempData["SubmissionResults"]) == true)
            {
                ViewData["SubmissionResults"] = true;
            }

            string loginID = HttpContext.Session.GetString("loginID");
            Staff staff = staffDAL.GetStaffDetails(loginID);

            HttpContext.Session.SetInt32("StaffID", staff.StaffID);

            HttpContext.Session.SetString("Appointment", staff.Appointment);

            HttpContext.Session.SetString("Name", staff.StaffName);
            ViewData["name"] = staff.StaffName;
            ViewData["Role"] = staff.Appointment;

            return View();
        }
        
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: StaffController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StaffController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StaffController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: StaffController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        // GET: StaffController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: StaffController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public IActionResult ParcelList()
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }
            int? StaffID = HttpContext.Session.GetInt32("StaffID");
            if (StaffID != null)
            {
                List<Parcel> parcelList = parcelDAL.GetStaffParcelList((int)StaffID);
                if (parcelList.Count > 0)
                {
                    ViewData["isExist"] = true;
                    ViewData["actiontype"] = "ParcelDetails";
                }
                else
                {
                    ViewData["isExist"] = false;

                }
                return View("parcel", parcelList);
            }
            return View("parcel");

        }



        [HttpPost]
        public IActionResult ParcelDetails(IFormCollection ParcelData)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }
            int? deliverymanID;
            ViewData["ShowDetails"] = true;
            if (ParcelData["deliveryManId"] != "")
            {
                deliverymanID = Convert.ToInt32(ParcelData["deliveryManId"]);
            }
            else
            {
                deliverymanID = null;
            }
            Parcel parcel = new Parcel
            {
                ParcelID = Convert.ToInt32(ParcelData["parcelId"]),
                ItemDescription = ParcelData["itemDescription"],
                SenderName = ParcelData["senderName"],
                SenderTelNo = ParcelData["senderTelNo"],
                ReceiverName = ParcelData["receiverName"],
                ReceiverTelNo = ParcelData["receiverTelNo"],
                DeliveryAddress = ParcelData["deliveryAddress"],
                FromCity = ParcelData["fromCity"],
                ToCountry = ParcelData["toCountry"],
                FromCountry = ParcelData["fromCountry"],
                ToCity = ParcelData["toCity"],
                ParcelWeight = Convert.ToDouble(ParcelData["parcelWeight"]),
                DeliveryCharge = Convert.ToDecimal(ParcelData["deliveryCharge"]),
                Currency = ParcelData["currency"],
                TargetDeliveryDate = Convert.ToDateTime(ParcelData["targetDeliveryDate"]),
                DeliveryStatus = ParcelData["deliveryStatus"],
                DeliveryManID = deliverymanID
            };
            if (parcel != null)
            {
                if (parcel.DeliveryStatus == "0")
                {
                    parcel.DeliveryStatus = "Pending Delivery";
                }
                else if (parcel.DeliveryStatus == "1")
                {
                    parcel.DeliveryStatus = "Delivery to destination in progress";
                }
                else if (parcel.DeliveryStatus == "2")
                {
                    parcel.DeliveryStatus = "Delivery to airport in progress";
                }
                else if (parcel.DeliveryStatus == "3")
                {
                    parcel.DeliveryStatus = "Delivery completed";
                }
                else if (parcel.DeliveryStatus == "4")
                {
                    parcel.DeliveryStatus = "Delivery has failed. Delivery is schedule to another day.";
                }
            }
            parcelDetails.Add(parcel);

            return View("Parcel", parcelDetails);
        }





    }
}
