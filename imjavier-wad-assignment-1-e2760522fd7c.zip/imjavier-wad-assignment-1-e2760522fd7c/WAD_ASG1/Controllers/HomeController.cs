﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WAD_ASG1.Models;
using WAD_ASG1.DAL;
using System.Text.RegularExpressions;
using System.Web;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics.Metrics;

namespace WAD_ASG1.Controllers
{
    public class HomeController : Controller
    {
        private memberDAL memberContext = new memberDAL();
        private staffDAL staffContext = new staffDAL();


        [HttpPost]
        public ActionResult AuthenticateUser(IFormCollection formData)
        {
            string loginID = formData["txtLoginID"].ToString().ToLower();
            bool VerifyEmail = EmailInput(loginID);

            if (VerifyEmail == true)
            {
                return MemberLogin(formData);

            }
            else
            {
                return StaffLogin(formData);
            }

        }

        private bool EmailInput(string userInput)
        {
            string RegularExpression = @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$";

            return Regex.IsMatch(userInput, RegularExpression);
        }

        public ActionResult StaffLogin(IFormCollection formData)
        {
            string loginID = formData["txtLoginID"].ToString();
            string password = formData["txtPassword"].ToString();

            if (staffContext.Login(loginID, password))
            {

                HttpContext.Session.SetString("loginID", loginID);
                HttpContext.Session.SetString("Role", "Staff");
                return RedirectToAction("Index", "staff");

            }
            else
            {
                TempData["message"] = "User is not found or password is incorrect";
                return RedirectToAction("Login");
            }
        }

        public ActionResult MemberLogin(IFormCollection formData)
        {
            string loginID = formData["txtLoginID"].ToString();
            string password = formData["txtPassword"].ToString();
            if (memberContext.Login(loginID, password) == true)
            {
                HttpContext.Session.SetString("loginID", loginID);
                HttpContext.Session.SetString("Role", "Member");

                return RedirectToAction("Index", "Member"); 
            }
            else
            {
                TempData["message"] = "User is not found or password is incorrect";
                return RedirectToAction("Login");
            }
        }

        public ActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
        public IActionResult Index()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Login()
        {

            if(HttpContext.Session.GetString("loginID") == "Member")
            {
                return RedirectToAction("Index", "Member");
            }
            else
            {
                return View();
            }

        }
        public IActionResult AboutUs()
        {
            return View("About Us");
        }

        public IActionResult Contact() { return View("Contact"); }




        [HttpPost]
        public ActionResult CompletedSignUp1(IFormCollection formData)
        {
            if (HttpContext.Session.GetString("loginID") != null)
            {
                if (HttpContext.Session.GetString("Role") == "Member")
                {
                    return RedirectToAction("Index", "Member");
                }
                else if (HttpContext.Session.GetString("Staff") == "Staff")
                {
                    return RedirectToAction("Index", "staff");
                }
            }
            bool isEmail = EmailInput(formData["email"]);
            if (isEmail == false)
            {
                TempData["SignUpErrMessage"] = "Please enter an email";
                return RedirectToAction("SignUp1");
            }
            HttpContext.Session.SetString("email", formData["email"]);
            HttpContext.Session.SetString("password", formData["password"]);
            if(memberContext.IsEmailExist(formData["email"]) == false)
            {
                return RedirectToAction("SignUp2");
            }
            else
            {
                TempData["SignUpErrMessage"] = "Email belongs to an existing user. Please choose another one or login with that email";
                return RedirectToAction("SignUp1");
            }
            
            
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CompletedSignUp2(IFormCollection formData)
        {

            Member member = new Member();
            member.MemberName = formData["membername"];
            member.Salutation = formData["salutation"];
            member.TelNo = formData["telno"];
            member.EmailAddr = HttpContext.Session.GetString("email");
            member.Password = HttpContext.Session.GetString("password");
            member.BirthDate = Convert.ToDateTime(formData["birthday"]);
            member.City = formData["city"];
            member.Country = formData["country"];
            memberContext.Add(member);
            string email = member.EmailAddr;
            HttpContext.Session.SetString("loginID", member.EmailAddr);
            return RedirectToAction("Index", "Member");

        }

        public ActionResult SignUp1()
        {
            if (HttpContext.Session.GetString("loginID") != null)
            {
                if (HttpContext.Session.GetString("Role") == "Member")
                {
                    return RedirectToAction("Index", "Member");
                }
                else if (HttpContext.Session.GetString("Staff") == "Staff")
                {
                    return RedirectToAction("Index", "staff");
                }
            }
            return View("SignUpStep1");           
        }

        public ActionResult SignUp2()
        {
            if (HttpContext.Session.GetString("loginID") != null)
            {
                if (HttpContext.Session.GetString("Role") == "Member")
                {
                    return RedirectToAction("Index", "Member");
                }
                else if (HttpContext.Session.GetString("Staff") == "Staff")
                {
                    return RedirectToAction("Index", "staff");
                }
            }
            Member member = new Member();
            ViewData["Salutation"] = GetSalutation();
            return View("SignUpStep2", member);
        }

        public ActionResult Create()
        {
            
            return View();
        }

        private List<SelectListItem> GetSalutation()
        {
            List<SelectListItem> salutationList = new List<SelectListItem>();
            salutationList.Add(new SelectListItem
            {
                Value = "Mr",
                Text = "Mr"
            });
            salutationList.Add(new SelectListItem
            {
                Value = "Ms",
                Text = "Ms"
            });
            salutationList.Add(new SelectListItem
            {
                Value = "Mrs",
                Text = "Mrs"
            });

            return salutationList;


        }

    }



}