﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WAD_ASG1.DAL;
using WAD_ASG1.Models;

namespace WAD_ASG1.Controllers
{
    public class FeedbackController : Controller
    {
        private feedbackEnquiryDAL FeedbackenquiryDAL = new feedbackEnquiryDAL();
        // GET: FeedbackController
        public ActionResult CustomerEnquiries()
        {
            List<FeedbackEnquiry> feedList = FeedbackenquiryDAL.GetAllFeedbackEnquiry();
            ViewData["isExist"] = true;
            return View("CustomerEnquiries", feedList);
        }

        // GET: FeedbackController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: FeedbackController/Create
        public ActionResult Create(string feedback)
        {
            return View();
        }

        // POST: FeedbackController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FeedbackController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: FeedbackController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FeedbackController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: FeedbackController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        [HttpPost]
        public IActionResult ViewEnquiry(IFormCollection formdata)
        {
            int? StaffID = null;
            if(formdata["StaffID"] != "")
            {
                StaffID = Convert.ToInt32(formdata["StaffID"]);
            }
            


            FeedbackEnquiry feedbackenquiry = new FeedbackEnquiry
            {
                FeedbackEnquiryID = Convert.ToInt32(formdata["FeedbackEnquiryID"]),
                MemberID = Convert.ToInt32(formdata["MemberID"]),
                Content = formdata["content"],
                DateTimePosted = Convert.ToDateTime(formdata["DateTimePosted"]),
                Response = formdata["Response"],
                StaffID = StaffID,
                Status = formdata["status"]

            };
            return View("Enquirydetails", feedbackenquiry);
            
        }
        [HttpPost]
        public IActionResult SubmitEnquiry(IFormCollection formdata)
        {
            int FeedID = Convert.ToInt32(formdata["FeedbackEnquiryID"]);
            string? Response = formdata["Response"];
            if (Response == "")
            {
                Response = null;
            }
            int? StaffID = HttpContext.Session.GetInt32("StaffID");
            bool isUpdated = FeedbackenquiryDAL.Update(FeedID, StaffID, Response);
            if (isUpdated)
            {
                ViewData["ReportConfirmation"] = true;
                return CustomerEnquiries();
            }
            else
            {
                ViewData["ReportConfirmation"] = false;
                ViewData["ErrMsg"] = "Something went wrong please try again";
                return CustomerEnquiries();
            }





        }
    }
}
