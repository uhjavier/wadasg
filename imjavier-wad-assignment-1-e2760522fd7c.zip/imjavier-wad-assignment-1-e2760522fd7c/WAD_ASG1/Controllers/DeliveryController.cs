﻿using Microsoft.AspNetCore.DataProtection.KeyManagement.Internal;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Metadata;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WAD_ASG1.DAL;
using WAD_ASG1.Models;
using System.Transactions;

namespace WAD_ASG1.Controllers
{

    public class DeliveryController : Controller
    {
        // GET: CalculateController
        private parcelDAL parcelDAL = new();
        private staffDAL staffDAL = new();
        private deliveryHistoryDAL deliveryHistoryDAL = new();
        private deliveryFailureDAL deliveryFailureDAL = new deliveryFailureDAL();
        private List<string> failureReasons = new List<string>() { "Receiver not found", "Wrong delivery address", "Parcel damaged", "Others" };
        private List<SelectListItem> selectreasons = new List<SelectListItem>();
        private List<DeliveryFailure> deliveryFailures = new();
        private ApiController apiController = new();
        
       
        public DeliveryController() 
        {
            int i = 0;
            foreach (var failure in failureReasons)
            {
                selectreasons.Add(new SelectListItem { Text = failure.ToString(), Value = i.ToString() }) ;
                i++;
            }
        
        }
        public ActionResult Index()
        {
            return View();
        }



        // GET: CalculateController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CalculateController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CalculateController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: CalculateController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CalculateController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: CalculateController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
        public IActionResult parcelList(bool check) 
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }

            if (check == true)
            {
                ViewData["ReportConfirmation"] = true;
            }
            else if (Convert.ToBoolean(TempData["request"]))
            {
                ViewData["failedrequest"] = true;
            } 
            int? StaffID = HttpContext.Session.GetInt32("StaffID");
            if (StaffID != null)
            {
                List<Parcel> parcelList = parcelDAL.GetStaffParcelList((int)StaffID);
                if (parcelList.Count > 0)
                {
                    ViewData["isExist"] = true;
                    ViewData["actiontype"] = "ParcelDetails";
                    ViewData["isDelivered"] = false;
                }
                else
                {
                    ViewData["isExist"] = false;

                }

                return View("parcels", parcelList);
            }

            return View("parcels");
        }
        public IActionResult ParcelDetails(IFormCollection ParcelData) 
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }
            int? deliverymanID;
            ViewData["ShowDetails"] = true;
            List<Parcel> parcelDetails = new List<Parcel>();
            if (ParcelData["deliveryManId"] != "")
            {
                deliverymanID = Convert.ToInt32(ParcelData["deliveryManId"]);
            }
            else
            {
                deliverymanID = null;
            }
            Parcel parcel = new Parcel
            {
                ParcelID = Convert.ToInt32(ParcelData["parcelId"]),
                ItemDescription = ParcelData["itemDescription"],
                SenderName = ParcelData["senderName"],
                SenderTelNo = ParcelData["senderTelNo"],
                ReceiverName = ParcelData["receiverName"],
                ReceiverTelNo = ParcelData["receiverTelNo"],
                DeliveryAddress = ParcelData["deliveryAddress"],
                FromCity = ParcelData["fromCity"],
                ToCountry = ParcelData["toCountry"],
                FromCountry = ParcelData["fromCountry"],
                ToCity = ParcelData["toCity"],
                ParcelWeight = Convert.ToDouble(ParcelData["parcelWeight"]),
                DeliveryCharge = Convert.ToDecimal(ParcelData["deliveryCharge"]),
                Currency = ParcelData["currency"],
                TargetDeliveryDate = Convert.ToDateTime(ParcelData["targetDeliveryDate"]),
                DeliveryStatus = ParcelData["deliveryStatus"],
                DeliveryManID = deliverymanID
            };
            if (parcel != null)
            {
                if (parcel.DeliveryStatus == "0")
                {
                    parcel.DeliveryStatus = "Pending Delivery";
                }
                else if (parcel.DeliveryStatus == "1")
                {
                    parcel.DeliveryStatus = "Delivery to destination in progress";
                }
                else if (parcel.DeliveryStatus == "2")
                {
                    parcel.DeliveryStatus = "Delivery to airport in progress";
                }
                else if (parcel.DeliveryStatus == "3")
                {
                    parcel.DeliveryStatus = "Delivery completed";
                }
                else if (parcel.DeliveryStatus == "4")
                {
                    parcel.DeliveryStatus = "Delivery has failed. Delivery is schedule to another day.";
                }
            }
            parcelDetails.Add(parcel);
            ViewData["ViewType"] = "Parcel Details";
            return View("Parcels", parcel);
        }
        [HttpPost]
        public IActionResult Deliveryfailure(IFormCollection parcelInfo) 
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }
            DeliveryFailure report = new DeliveryFailure
            {
                ParcelID = Convert.ToInt32(parcelInfo["ParcelID"]),
                DeliveryManID = Convert.ToInt32(parcelInfo["DeliveryManID"])

            };
            ViewData["failuretype"] = selectreasons;

            return View(report);
        
        }
        [HttpPost]
        public IActionResult FailureReport(IFormCollection parcelInfo)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }
            DeliveryFailure report = new DeliveryFailure
            {
                ParcelID = Convert.ToInt32(parcelInfo["ParcelID"]),
                DeliveryManID = Convert.ToInt32(parcelInfo["DeliveryManID"]),
                Description = parcelInfo["Description"],
                FailureType = parcelInfo["FailureType"],
                StationMgrID = null,
                FollowUpAction = null,
                DateCreated = DateTime.Now,
            };
            report = deliveryFailureDAL.Add(report);
            TempData["ReportResult"] = true;
            return parcelList(true);
        }
        [HttpPost]
        public IActionResult UpdateStatus(IFormCollection ParcelData)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }
            int ParcelID = Convert.ToInt32(ParcelData["ParcelID"]);
            string ParcelCountryDestination = ParcelData["ToCountry"];
            string? deliverymanID = HttpContext.Session.GetString("loginID");
            string DateCreated = DateTime.Now.ToString("dd MMM yyyy hh:mm tt");
            string deliveryDesc = "";
            bool isLocal;
            int parcelstatus;
            if (ParcelCountryDestination.ToLower() == "singapore")
            {
                deliveryDesc = $"Parcel delivered by {deliverymanID} on {DateCreated}";
                isLocal = true;
                parcelstatus = 3;
            }
            else
            {
                deliveryDesc = $"Parcel delivered to airport by {deliverymanID} on {DateCreated}";
                isLocal = false;
                parcelstatus = 2;
            }
            List<int> parcelInfo = new List<int>() {ParcelID, parcelstatus };
            DeliveryHistory deliveryHistory = new DeliveryHistory()
            {
                Description = deliveryDesc,
                ParcelID = ParcelID
            };

                    bool isUpdated = parcelDAL.Update(parcelInfo);
                    bool isAdded = deliveryHistoryDAL.Add(deliveryHistory);
                    if (isUpdated && isAdded)
                    {
                        return parcelList(true);
                    }

      



            return parcelList(true);


        }

        public async Task<IActionResult> WeatherForecast()
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }
            combinedForecast CombinedForcast = await apiController.combinedForecast();
            return View("weatherinfo", CombinedForcast);
        }

        public async Task<IActionResult> TrafficInfo()
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") != "Staff")
            {
                return RedirectToAction("Index", "Member");
            }
            else if (HttpContext.Session.GetString("Appointment") != "Delivery Man")
            {
                return RedirectToAction("Index", "Staff");
            }
            TrafficIncident trafficIncidentInfo = await apiController.trafficInfo();
            return View(trafficIncidentInfo);
        }
    }
}
