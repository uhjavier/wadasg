﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography.X509Certificates;
using WAD_ASG1.DAL;
using WAD_ASG1.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Newtonsoft.Json;

namespace WAD_ASG1.Controllers
{
    public class MemberController : Controller
    {
        private parcelDAL parcelDAL = new parcelDAL();
        private memberDAL memberDAL = new memberDAL();
        private feedbackEnquiryDAL feedDAL = new feedbackEnquiryDAL();
        private Member UserContext;
        private List<string> honorific = new List<string>() { "Mr", "Mrs", "Ms" };
        private List<SelectListItem> SalutationList = new List<SelectListItem>();
        private List<Parcel> parcelDetails = new List<Parcel>();
        private WeatherForecast weatherForecast = new WeatherForecast();
        private WeatherForecast2hr weatherForecast2hr = new WeatherForecast2hr();
        private combinedForecast combinedForecast = new combinedForecast();
        private ApiController apiController = new ApiController();
        // GET: HomeController1
        public MemberController()
        {
            foreach (string i in honorific)
            {
                SalutationList.Add(new SelectListItem { Text = i, Value = i });
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<IActionResult> Index(string loginID)
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") == "Staff")
            {
                return RedirectToAction("index", "staff");
            }

            if (HttpContext.Session.GetString("loginID") != null)
            {

                string MemberEmail = HttpContext.Session.GetString("loginID");
                UserContext = memberDAL.GetMemberDetails(MemberEmail);
                string username = UserContext.MemberName.ToString();
                ViewData["username"] = username;
                ViewData["userSalutation"] = UserContext.Salutation; 
                HttpContext.Session.SetString("Name", username);
                HttpContext.Session.SetInt32("MemberId", UserContext.MemberId);
                combinedForecast = await apiController.combinedForecast();
                return View(combinedForecast);

            }
            else
            {
                return RedirectToAction("Login", "Home");
            }



        }
        public IActionResult Enquiry()
        {
                        if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") == "Staff")
            {
                return RedirectToAction("index", "staff");
            }
            return View();
        }
        // GET: HomeController1/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }


        // GET: HomeController1/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: HomeController1/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: HomeController1/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: HomeController1/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: HomeController1/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: HomeController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }



        public ActionResult EditProfile()
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") == "Staff")
            {
                return RedirectToAction("index", "staff");
            }

            string MemberEmail = HttpContext.Session.GetString("loginID");
            Member userContext = memberDAL.GetMemberDetails(MemberEmail);
            ViewData["Salutation"] = SalutationList;
            return View("editprofile", userContext);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateProfile(Member member)
        {
            Member NewMemberContext = member;
            
            string MemberEmail = HttpContext.Session.GetString("loginID");
            UserContext = memberDAL.GetMemberDetails(MemberEmail);
            if(NewMemberContext.EmailAddr != UserContext.EmailAddr)
            {
                bool IsExist = memberDAL.IsEmailExist(NewMemberContext.EmailAddr);
                if (IsExist)
                {
                    TempData["EmailExists"] = "Email already exists, please choose another one";
                    return EditProfile();
                }
            }
            CompareModels comparer = new CompareModels();
            Dictionary<string, string> NewInfo = comparer.findDifferences(UserContext, NewMemberContext);
            int totalItems = NewInfo.Count;
            int Index = 0;
            int Index2 = 0;
            if (NewInfo.ContainsKey("Name") && NewInfo.ContainsKey("TelNo"))
            {
                Index2 = 0;
            }
            else if(NewInfo.ContainsKey("Name") | NewInfo.ContainsKey("TelNo"))
            {
                Index2++;
            }
            string QueryForParcelTable = "update parcel set ";
            string QueryForParcelTable2 = "update parcel set ";
            string QueryForMemberTable = "update member set ";
            foreach (KeyValuePair<string, string> pair in NewInfo)
            {
                string addToQuery = $"{pair.Key} = '{pair.Value}'";
                QueryForMemberTable += addToQuery;
                if (Index + 1 < totalItems)
                {
                    QueryForMemberTable += ",";
                }
                if ((pair.Key == "Name" | pair.Key == "TelNo"))
                {
                    QueryForParcelTable += "Sender" + addToQuery;
                    QueryForParcelTable2 += "Receiver" + addToQuery;
                    if (Index2 < 1)
                    {
                        QueryForParcelTable += ",";
                        QueryForParcelTable2 += ",";
                        Index2++;
                    }
                }

                if (Index == totalItems - 1)
                {
                    QueryForMemberTable += $" where Emailaddr = '{UserContext.EmailAddr}'";
                    QueryForParcelTable += $" where (sendername = '{UserContext.MemberName}' and sendertelno = '{UserContext.TelNo}')";
                    QueryForParcelTable2 += $" where (receivername = '{UserContext.MemberName}' and receivertelno = '{UserContext.TelNo}') ";
                }

                Index++;
            }
            
            bool isUpdated1 = memberDAL.ExecuteQuery(QueryForParcelTable);
            bool isUpdated2 = memberDAL.ExecuteQuery(QueryForParcelTable2);
            bool isUpdated = memberDAL.ExecuteQuery(QueryForMemberTable);
            HttpContext.Session.SetString("Name", NewMemberContext.MemberName);
            HttpContext.Session.SetInt32("MemberId", UserContext.MemberId);
            HttpContext.Session.SetString("loginID", NewMemberContext.EmailAddr);
            return EditProfile();
        }
        public IActionResult Parcel()
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") == "Staff")
            {
                return RedirectToAction("index", "staff");
            }

            if (HttpContext.Session.GetString("loginID") != null)
            {
                string MemberEmail = HttpContext.Session.GetString("loginID");
                UserContext = memberDAL.GetMemberDetails(MemberEmail);
                List<Parcel> MemberParcels = parcelDAL.getMemberParcels(UserContext);
                if (MemberParcels.Count > 0)
                {
                    foreach (Parcel parcel in MemberParcels)
                    {
                        if (parcel != null)
                        {
                            if (parcel.DeliveryStatus == "0")
                            {
                                parcel.DeliveryStatus = "Pending Delivery";
                            }
                            else if (parcel.DeliveryStatus == "1")
                            {
                                parcel.DeliveryStatus = "Delivery to destination in progress";
                            }
                            else if (parcel.DeliveryStatus == "2")
                            {
                                parcel.DeliveryStatus = "Delivery to airport in progress";
                            }
                            else if (parcel.DeliveryStatus == "3")
                            {
                                parcel.DeliveryStatus = "Delivery completed";
                            }
                            else if (parcel.DeliveryStatus == "4")
                            {
                                parcel.DeliveryStatus = "Delivery has failed. Delivery will be scheduled to another day.";
                            }
                        }
                    }

                }
                else
                {
                    ViewData["ParcelInfo"] = "no records found";
                }
                ViewData["ShowDetails"] = false;
                ViewData["actiontype"] = "parceldetails";
                return View(MemberParcels);
            }
            return RedirectToAction("Index", "home");
        }

        public IActionResult CreateEnquiry()
        {
            if (HttpContext.Session.GetString("Role") == null)
            {
                return RedirectToAction("login", "Home");
            }
            else if (HttpContext.Session.GetString("Role") == "Staff")
            {
                return RedirectToAction("index", "staff");
            }

            ViewData["SubmissionResults"] = false;
            return View("_Enquiry");
        }
        [HttpPost]
        public ActionResult ParcelDetails(IFormCollection ParcelData) 
        {
            int? deliverymanID;
            ViewData["ShowDetails"] = true;
            if (ParcelData["deliveryManId"] != "") 
            {
                deliverymanID = Convert.ToInt32(ParcelData["deliveryManId"]);
            }
            else
            {
                deliverymanID=null;
            }
            Parcel parcel = new Parcel
            {
                ParcelID = Convert.ToInt32(ParcelData["parcelId"]),
                ItemDescription = ParcelData["itemDescription"],
                SenderName = ParcelData["senderName"],
                SenderTelNo = ParcelData["senderTelNo"],
                ReceiverName = ParcelData["receiverName"],
                ReceiverTelNo = ParcelData["receiverTelNo"],
                DeliveryAddress = ParcelData["deliveryAddress"],
                FromCity = ParcelData["fromCity"],
                ToCountry = ParcelData["toCountry"],
                FromCountry = ParcelData["fromCountry"],
                ToCity = ParcelData["toCity"],
                ParcelWeight = Convert.ToDouble(ParcelData["parcelWeight"]),
                DeliveryCharge = Convert.ToDecimal(ParcelData["deliveryCharge"]),
                Currency = ParcelData["currency"],
                TargetDeliveryDate = Convert.ToDateTime(ParcelData["targetDeliveryDate"]),
                DeliveryStatus = ParcelData["deliveryStatus"],
                DeliveryManID = deliverymanID
            };

            parcelDetails.Add(parcel);

            return View("Parcel", parcelDetails); 
        }



        [HttpPost]

        public ActionResult CreateEnquiry(IFormCollection Enquiry)
        {


            string feedbackContent = Enquiry["Content"];
            DateTime datePosted = DateTime.Now;
            int MemberID = (int)HttpContext.Session.GetInt32("MemberId");
            FeedbackEnquiry feedbackEnquiry = new FeedbackEnquiry()
            {
                MemberID = MemberID,
                Content = feedbackContent,
                DateTimePosted = datePosted,
                StaffID = null,
                Response = null,
                Status = "0"
            };
            
            feedDAL.Add(feedbackEnquiry);
            ViewData["SubmissionResults"] = true;
            TempData["SubmitSuccess"]="Enquiry Submitted! We will get back to you as soon as possible.";
            return View("_Enquiry");
        }

        public IActionResult EnquiryHistory()
        {
            int MemberID = (int)HttpContext.Session.GetInt32("MemberId");
            List<FeedbackEnquiry> MemberFeedList = feedDAL.GetMemberFeedbackEnquiry(MemberID);
            if (MemberFeedList != null && MemberFeedList.Count > 0)
            {
                ViewData["isExist"] = true;
                return View("memberEnquiries", MemberFeedList);
            }
            else
            {
                ViewData["isExist"] = false;
                return View("memberEnquiries");
            }
        }


    }

    public class CompareModels
    {
        public Dictionary<string, string> findDifferences(Member MemberInfo, Member NewMemberInfo)
        {
            Dictionary<string, string> DifferencesDict = new Dictionary<string, string>();
            if (MemberInfo.MemberName != NewMemberInfo.MemberName)
            {
                DifferencesDict.Add("Name", NewMemberInfo.MemberName);
            }
            if (MemberInfo.Salutation != NewMemberInfo.Salutation)
            {
                DifferencesDict.Add("Salutation", NewMemberInfo.Salutation);
            }
            if(MemberInfo.TelNo != NewMemberInfo.TelNo)
            {
                DifferencesDict.Add("TelNo", NewMemberInfo.TelNo);
            }
            if(MemberInfo.EmailAddr != NewMemberInfo.EmailAddr)
            {
                DifferencesDict.Add("EmailAddr", NewMemberInfo.EmailAddr);
            }
            if(MemberInfo.BirthDate != NewMemberInfo.BirthDate)
            {
                DateTime? dateOfbirth = NewMemberInfo.BirthDate;
                string formattedDateOfBirth = dateOfbirth.HasValue ? dateOfbirth.Value.ToString("d-MMM-yyyy"): "oops";
                DifferencesDict.Add("BirthDate", formattedDateOfBirth);
            }
            if(NewMemberInfo.Password != null)
            {
                string? password = NewMemberInfo.Password;
                DifferencesDict.Add("Password", password);
            }
            return DifferencesDict;
        }
    }
  
}
